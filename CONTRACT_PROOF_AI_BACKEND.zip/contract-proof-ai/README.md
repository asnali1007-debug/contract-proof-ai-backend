# Contract Proof AI - backend MVP

Python FastAPI backend for the first, human-reviewed manned-security contract audit.
Supabase provides Auth, PostgreSQL and private file storage. OpenAI extracts **candidate facts only**.
Python `Decimal` calculations create **Potential** findings. An assigned internal analyst must validate
a finding before recording recovery progress.

This is source code ready for configuration and staging. It is **not deployed** and does not contain
credentials. The frontend/reviewer screens are not part of this backend; the reviewer queue and all
review actions are available through the API and development Swagger UI.

## 1. Install and run the local tests

Use Python 3.12 or later. Unzip the project, open a terminal in `contract-proof-ai`, and run:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.lock
python -m pip install --no-deps -e .
pytest -q
```

On Windows PowerShell, activate with `.venv\Scripts\Activate.ps1` instead.
The ordinary tests use fake external services and need no API keys. Seven integration tests skip
unless `TEST_DATABASE_URL` points to an empty, disposable PostgreSQL database whose name ends in
`_test`. They test actual SQL RLS policies and triggers, using small SQL fixtures for Supabase's Auth
and Storage schemas. The included GitHub Actions workflow supplies PostgreSQL 16 and runs them.
Never point the test suite at a customer or production database. It refuses to initialise an existing
`contract_proof` schema and never drops existing schemas.

Validation performed for this delivery is recorded in `VALIDATION.md`. Hosted Supabase Auth,
Storage, OpenAI calls and deployment still require a staging test with your project credentials.

## 2. Create the Supabase project and configure secrets

1. Create a Supabase project for this application.
2. In Supabase Auth, configure email/password sign-in. This MVP uses provisioned accounts:
   disable public sign-ups and create the client and internal analyst accounts through your
   approved administration process. Record their **Auth user UUIDs**. Client and analyst identities
   should be separate. The API does not expose self-service role assignment.
3. Copy `.env.example` to `.env` and fill in the Supabase URL, publishable/anon key, backend-only
   legacy service-role key, OpenAI API key and your chosen Structured Outputs-capable model.
4. Set `ADMIN_DATABASE_URL` temporarily for the setup commands. Obtain the administrator connection
   details from your project's database connection panel. Use TLS for hosted connections.
5. Apply migrations:

```bash
python scripts/migrate.py
```

This creates the private `contract_proof` schema, tenant tables, RLS policies, audit triggers,
restricted `contract_api` login and private `audit-files` bucket. The migration runner checks stored
checksums, applies the batch transactionally and safely skips unchanged applied migrations.
Do not both paste SQL manually and run the runner against the same schema.

6. Provision the first workspace and set the API database password interactively:

```bash
python scripts/provision.py --workspace-name "First client" --client CLIENT_AUTH_UUID --analyst ANALYST_AUTH_UUID --set-api-password
```

Replace the UUID placeholders. The script prints the workspace UUID. It does not create Auth users,
send email, contact a supplier or grant a global administrator role. To assign another existing member,
repeat with `--workspace-id WORKSPACE_UUID`; existing conflicting roles require an explicit admin review.
Use a distinct workspace for each client.

7. Set `DATABASE_URL` using the **contract_api** username and the password you just set. Do not use
   `postgres`, `service_role` or any table-owner/bypass-RLS login for the running API. The startup check
   refuses elevated roles, role memberships or table ownership. Use Supabase's direct connection or
   session pooler; follow its custom-role username format when using the pooler. Passwords containing
   URI-reserved characters must be URL-encoded in the connection string.
8. Remove `ADMIN_DATABASE_URL` from the web-service environment after provisioning. Keep all secrets
   in the backend host's secret manager. `.env` is excluded from git and Docker build context.

Keep `contract_proof` **out of Supabase's exposed API schemas**. Clients use FastAPI for record access.
Do not add direct authenticated write policies to the Storage bucket. If changing `STORAGE_BUCKET`,
change migration 002 consistently before applying it; the default is `audit-files`.

## 3. Start the API

```bash
uvicorn app.main:create_app --factory --host 127.0.0.1 --port 8000 --reload
```

Open [the development API documentation](http://127.0.0.1:8000/docs). `GET /health` is a liveness check.
Database safety checks and connection readiness run at startup.

Use `POST /auth/login` with the provisioned user's email/password. Copy the returned access token
into Swagger's **Authorize** dialog. Pass `Authorization: Bearer ACCESS_TOKEN` on every protected
request. `POST /auth/refresh`, `POST /auth/logout` and `GET /auth/me` handle session operations.
Logout revokes the refresh session through Supabase; access-token lifetime follows Supabase Auth.
Do not store tokens in URLs or application logs. No keys are returned by the API.

## 4. Complete the first audit

In the paths below, `{w}` is a workspace UUID and `{d}` is a diagnostic UUID. Obtain them through
`GET /workspaces` and `POST /workspaces/{w}/diagnostics` with `{"name":"September security audit"}`.

1. **Upload evidence as the client.** POST multipart `kind` and `file` to
   `/workspaces/{w}/diagnostics/{d}/documents`. Kinds: `contract`, `rate_card`, `invoice`,
   `payment_record`, `credit_note`, `timesheet`. Original bytes receive a SHA-256 digest and a
   generated private object path. GET a document to inspect its extracted text segments and locators.
2. **Extract as an assigned analyst.** POST `.../documents/{document_id}/extract` for contracts,
   rate cards, invoices and credit notes. Read `.../extractions` for status and warnings.
   Read `.../review-queue` for candidate rules and invoice lines. Extraction never approves an item.
   Payment records and timesheets are supporting evidence for human selection, not automatically
   matched transactions.
3. **Inspect source coverage.** Check all pages/rows, extraction warnings and invoice totals against
   the files. A source that lacks required data produces a warning instead of guessed facts. Enter
   missing/corrected candidates through `POST .../rules` or `POST .../invoice-lines`. Uploading a
   document or completing extraction is not a guarantee every invoice line was captured.
4. **Review rules.** POST `.../rules/{rule_id}/review` with an explicit decision, current version
   and reason, for example:

```json
{"decision":"approve","expected_version":1,"note":"Rate and effective dates checked against the signed contract."}
```

`edit` accepts a replacement `payload` and/or `evidence` and leaves the item **candidate**.
`approve` may include corrected fields, but is a separate explicit human decision. `reject` closes
the candidate. Approved/rejected records cannot be overwritten; create a corrected candidate before
running, rejecting the erroneous candidate before approval. To correct an already approved rule,
start a new diagnostic with the corrected evidence set. Stale versions return HTTP 409.

5. **Approve invoice inputs.** Edit an invoice line to select its `contract_rule_id`, `rate_rule_id`,
   one applicable `premium_rule_id` if needed, and `adjustment_rule_ids` for fees, variations and credits.
   Enter the verified hours and attach `hours_evidence` from a relevant uploaded source, such as an
   approved timesheet. Then POST `.../invoice-lines/{line_id}/review` with `decision=approve`.
   The API checks evidence quotations, rule approvals, matching supplier/version/service/currency,
   effective dates and pricing band. An example request shape is in `examples/`.
6. **Run the diagnostic.** POST `.../run`. All candidates must have been approved or rejected and
   no extraction may be running. Missing or conflicting calculation terms stop the entire run.
   Findings and calculation snapshots commit atomically. Repeating the request returns the same
   completed snapshot. Inputs are frozen after completion; new diagnostics provide corrected runs.
7. **Validate findings.** GET `.../findings`. Differences start as `Potential` and `Identified`.
   POST `.../findings/{finding_id}/review` with `decision=validate` or `reject`, `expected_version`
   and a note. Only an assigned analyst can do this.
8. **Record recovery.** PATCH `.../findings/{finding_id}/recovery`. The statuses are `Identified`,
   `Under Review`, `Supplier Query`, `Credit Note Pending`, `Recovered`, `Rejected`.
   `Identified` progresses first to `Under Review` or `Rejected`; the later stages follow the
   state machine in `app/review.py`. `Recovered` requires a positive `recovered_amount` no greater
   than the finding's overcharge, and evidence from a payment record or credit note. Partial recovery
   can be recorded as a final recovered amount; incremental recovery ledgers are outside this MVP.
   Recovery-evidence documents can still be uploaded after the diagnostic completes.
9. **Export.** GET `.../evidence-pack.pdf` or `.../evidence-pack.xlsx`. Both show all calculated lines,
   statuses, amounts, formulas, source document IDs, quotes, clauses, page/row locators and hashes.
   Use the document download endpoint to retrieve a referenced source. Exports are generated on
   demand. Export values are snapshots, not executable spreadsheet inputs.
10. **Inspect history.** GET `/workspaces/{w}/audit-log`. Database triggers record before/after
    review values and actors in the same transaction as uploads, extractions, decisions and recovery
    changes. Runtime users cannot insert, modify or delete these log rows. Export events use a
    restricted database function. Administrator provisioning is separately logged with an admin source.

## API map

All paths after `D` use `D=/workspaces/{workspace_id}/diagnostics/{diagnostic_id}`.

| Method and path | Purpose | Access |
| --- | --- | --- |
| POST `/auth/login`, `/auth/refresh` | Supabase sessions | Provisioned account |
| POST `/auth/logout`; GET `/auth/me` | Current session | Authenticated |
| GET `/workspaces`, `/workspaces/{w}/memberships` | Workspace scope | Workspace member |
| POST/GET `/workspaces/{w}/diagnostics`; GET `D` | Create/list/read audits | Workspace member |
| POST/GET `D/documents` | Upload/list files | Workspace member |
| GET `D/documents/{id}`, `D/documents/{id}/download` | Text/evidence and original file | Workspace member |
| POST `D/documents/{id}/extract`; GET `D/extractions` | Candidate extraction/status | Analyst starts; member reads |
| POST `D/extractions/{id}/abandon` | Recover a request interrupted over an hour ago | Assigned analyst |
| GET `D/review-queue` | Pending rules and lines | Assigned analyst |
| POST/GET `D/rules`, `D/invoice-lines` | Enter/list candidate inputs | Analyst creates; member reads |
| POST `D/rules/{id}/review`, `D/invoice-lines/{id}/review` | Approve/edit/reject | Assigned analyst |
| POST `D/run` | Deterministic calculation | Assigned analyst |
| GET `D/findings`; POST `D/findings/{id}/review` | Findings and decisions | Member reads; analyst decides |
| PATCH `D/findings/{id}/recovery` | Recovery status | Assigned analyst |
| GET `D/evidence-pack.pdf`, `D/evidence-pack.xlsx` | Download evidence packs | Workspace member |
| GET `/workspaces/{w}/audit-log` | Append-only history | Workspace member |

List endpoints use zero-based `offset` and bounded page sizes (100 documents/diagnostics/workspaces,
200 for most other lists). `/review-queue` applies its offset independently to rules and invoice lines.
Dates use ISO `YYYY-MM-DD`; send monetary values and quantities as decimal strings.

## Calculation contract and MVP limits

```text
labour = approved_hours * (contracted_rate + approved_hourly_variations) * approved_premium
expected = labour + approved_fixed_charges + labour * approved_management_percent / 100 - credits
difference = charged - expected
```

Only the final net line amount is rounded to two decimal places, with `ROUND_HALF_UP`.
The engine never uses AI or binary floats for monetary arithmetic. A reproducible test case is
`10 × (20 + 2) × 1.5 + 33 − 30 = GBP 333.00`; charged GBP 360.00 gives a GBP 27.00 Potential overcharge.
Positive and negative differences are retained separately. Matched lines remain in the diagnostic
and export but do not create findings. No currency totals are combined and no FX conversion runs.

- Supported currencies: GBP, EUR and USD, all at two decimal places. VAT, tax, invoice-level rounding,
  compounding fees, minimum charges, tiered rates and cross-currency calculations need a later engine
  extension. Do not force unsupported terms into the supported formula.
- One service date and one reviewer-selected pricing band per line. Split source lines with multiple
  dates/rates only when the allocation is supported by evidence. The engine does not guess holidays
  or overtime from dates. Weekend, overtime and bank-holiday bands each need an approved multiplier,
  including an explicit 1x rule where there is no uplift. Concurrent premiums are not stacked.
- Exactly one applicable approved contract-version and base-rate rule must exist for each line.
  Effective dates are inclusive. Overlapping approvals block the run.
- Percentage management fees are calculated only on premium-adjusted labour. Fixed fees and credits
  are explicit line allocations, applied once per diagnostic. Unique credit references prevent reuse
  across its lines. This is not a cross-diagnostic duplicate-payment/recovery ledger.
- Confidence is the minimum extraction score among the selected inputs. It is a heuristic and is
  never the probability a discrepancy is correct. Approval does not automatically raise that score.
- Uploads: 20 MiB maximum, up to 250 text-readable PDF pages, 400,000 extracted characters and bounded
  spreadsheet dimensions/ZIP expansion. XLSX and UTF-8 comma-delimited CSV are supported. Legacy XLS,
  macros, external workbook links and formulas are rejected. Save Excel sheets as **values** or CSV.
  PDFs with image-only pages need OCR before upload; this backend does not claim to perform OCR.
- Parsing runs in a separate process with time and memory limits on Linux. This is bounded parsing,
  not a malware-scanning service. Use a dedicated constrained container for untrusted documents.
- Extraction is synchronous, split into bounded source chunks. No tools are enabled for the model.
  Progress is recorded in the database before network calls. Provider refusals, incomplete output,
  invalid citations and missing values do not become active rules. A failed job can be retried; a
  completed job is not silently repeated. Configure staging ingress/request timeouts for this workload.
- By default there are at most 1,000 documents, 1,000 invoice lines and 5,000 rules per diagnostic.
  Split large audits. Recovery progress records internal decisions only: selecting `Supplier Query`
  does not send a message. Payments, ERP integrations, supplier contact and multi-agent orchestration
  are deliberately absent.

## Security and staging deployment

Run the supplied Dockerfile or the Uvicorn factory command behind HTTPS. Set `ENVIRONMENT=production`,
an explicit `TRUSTED_HOSTS` list and HTTPS `CORS_ORIGINS`. Production disables interactive API docs.
The Docker process runs as a non-root user. Use an ingress request-size limit and shared rate limiter
when running multiple processes/instances; the included rate limiter is per process. Limit request
concurrency and allow sufficient extraction request time. Do not log request bodies or authorisation
headers. Use database backup/restore and project retention settings appropriate to the client data.

Every database request sets the verified user UUID in **transaction-local** JWT claims and uses the
restricted role. RLS reads membership assignments from the database. Clients cannot assign roles or
write audit tables directly. Composite foreign keys prevent cross-workspace document references.
Storage reads independently use the caller's Auth token under Storage RLS. Only backend Storage
uploads/cleanup use the service-role key; application database queries never use that key.

Database and object storage do not share a transaction. If a stored upload's database commit fails,
the handler attempts cleanup. A process crash or failed cleanup can leave an unregistered private
object. It remains unreadable through the document-linked Storage policy; monitor
`orphan_upload_cleanup_required` operational events and reconcile unregistered objects administratively.
Database administrators and the service-role secret remain trusted privileged actors; this is an
append-only application log, not a cryptographically tamper-proof external archive.

The OpenAI request uses Structured Outputs and `store=False`, which does not itself establish zero
data retention for the account. Configure your account's data controls before sending client documents.
Implementation references: [OpenAI Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs),
[OpenAI data controls](https://developers.openai.com/api/docs/guides/your-data),
[Supabase RLS](https://supabase.com/docs/guides/database/postgres/row-level-security),
[Supabase Storage access control](https://supabase.com/docs/guides/storage/security/access-control).

Before processing real client files, run the included PostgreSQL tests and a staging workflow with
two client accounts and an assigned/unassigned analyst against your actual Supabase project. Verify
upload, extraction, approval, calculation, export and cross-workspace denial with the configured
secrets. None of these steps require or perform supplier contact or payment actions.
