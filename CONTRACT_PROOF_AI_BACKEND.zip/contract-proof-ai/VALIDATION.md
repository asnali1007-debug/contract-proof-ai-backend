# Validation record

Date: 8 September 2026. Runtime: Python 3.12.13.

## Executed locally

- `pytest -q`: **67 passed, 7 skipped**. One non-failing upstream Starlette/AnyIO deprecation warning.
- `ruff check app tests scripts`: passed.
- `python -m compileall -q app scripts tests`: passed.
- Development OpenAPI generated successfully: 26 paths, including paths with multiple methods.
- Sample PDF evidence pack rendered and visually inspected across both pages. Embedded fonts avoid
  viewer substitution; evidence labels remain with their quotes and document identifiers.
- Excel evidence pack reopened and checked for exact expected/charged/difference values and absence
  of executable formulas originating from untrusted strings.

The executed tests cover approval gates, immutable decisions, stale versions, fixed/percentage fees,
premiums, hourly variations, credit reuse, duplicate invoice identities, negative differences, date
and currency mismatches, decimal rounding and calculation precision. They also cover file signatures,
upload limits, malformed files, compressed XLSX limits, formula rejection, source locators, unverified
citations, API authorisation, full findings/recovery workflow, extraction failures, idempotent runs,
frozen diagnostic inputs, credential redaction, source downloads and exports.

External services and the API test database are test doubles. The installed OpenAI SDK's actual
request serialisation and Structured Output parsing were also exercised using a mocked HTTP transport.
No external OpenAI request or client document transmission occurred.

## Not executed in this environment

The seven tests in `tests/test_postgres_rls.py` require an empty, disposable PostgreSQL database.
This environment could not start a PostgreSQL server, so these tests were **skipped**, not passed.
They are included in `.github/workflows/tests.yml`, which provisions PostgreSQL 16, but that CI
workflow has not been run here. The SQL migration/policy behaviour needs that real database check.

Hosted Supabase Auth and Storage, database credentials, project-specific RLS configuration, model
access and live OpenAI extraction were not verified. No Supabase project, secrets, GitHub repository
or backend host was connected, and no deployment was performed. Follow the README to configure a
staging project and run the real integration checks before using client data.
