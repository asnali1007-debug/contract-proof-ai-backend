insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('audit-files','audit-files',false,20971520,
  array['application/pdf','text/csv','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'])
on conflict(id) do update set public=false,file_size_limit=excluded.file_size_limit,
  allowed_mime_types=excluded.allowed_mime_types;

create function contract_proof.storage_visible(object_name text) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from contract_proof.documents d
    join contract_proof.memberships m on m.workspace_id=d.workspace_id
    where d.object_key=object_name and m.user_id=(select auth.uid()));
$$;
revoke all on function contract_proof.storage_visible(text) from public;
grant usage on schema contract_proof to authenticated;
grant execute on function contract_proof.storage_visible(text) to authenticated;

create policy contract_files_read on storage.objects for select to authenticated
  using (bucket_id='audit-files' and contract_proof.storage_visible(name));
-- Restrictive policies also protect this bucket from unrelated broad policies.
create policy contract_files_read_guard on storage.objects as restrictive for select to public
  using (bucket_id<>'audit-files' or
    (auth.role()='authenticated' and contract_proof.storage_visible(name)));
create policy contract_files_insert_guard on storage.objects as restrictive for insert to public
  with check (bucket_id<>'audit-files');
create policy contract_files_update_guard on storage.objects as restrictive for update to public
  using (bucket_id<>'audit-files') with check (bucket_id<>'audit-files');
create policy contract_files_delete_guard on storage.objects as restrictive for delete to public
  using (bucket_id<>'audit-files');
-- Only the backend's Storage writer uses the service-role credential.
-- The bucket id must match STORAGE_BUCKET. Update this migration if you rename it.
