-- Run once using the project database administrator. Never expose contract_proof via PostgREST.
create schema contract_proof;
revoke all on schema contract_proof from public, anon, authenticated;

do $$ begin
  if not exists (select 1 from pg_roles where rolname = 'contract_api') then
    create role contract_api login noinherit nosuperuser nocreatedb nocreaterole nobypassrls;
  end if;
end $$;
grant usage on schema contract_proof, auth to contract_api;
grant execute on function auth.uid() to contract_api;

create table contract_proof.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(name) between 1 and 200),
  created_at timestamptz not null default now()
);
create table contract_proof.memberships (
  workspace_id uuid not null references contract_proof.workspaces(id),
  user_id uuid not null references auth.users(id),
  role text not null check (role in ('client','analyst')),
  created_at timestamptz not null default now(),
  primary key (workspace_id,user_id)
);
create index memberships_user on contract_proof.memberships(user_id,workspace_id);

create function contract_proof.has_access(w uuid, analyst_only boolean default false)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from contract_proof.memberships m
    where m.workspace_id=w and m.user_id=(select auth.uid())
      and (not analyst_only or m.role='analyst'));
$$;
revoke all on function contract_proof.has_access(uuid,boolean) from public;
grant execute on function contract_proof.has_access(uuid,boolean) to contract_api;

create table contract_proof.diagnostics (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references contract_proof.workspaces(id),
  name text not null check (length(name) between 1 and 200),
  state text not null default 'Draft' check (state in ('Draft','Completed')),
  results jsonb not null default '[]',
  created_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  unique (workspace_id,id)
);
create table contract_proof.documents (
  id uuid primary key,
  workspace_id uuid not null,
  diagnostic_id uuid not null,
  kind text not null check (kind in ('contract','rate_card','invoice','payment_record','credit_note','timesheet')),
  filename text not null check (length(filename) between 1 and 180),
  media_type text not null,
  byte_size integer not null check (byte_size between 1 and 20971520),
  sha256 text not null check (sha256 ~ '^[0-9a-f]{64}$'),
  object_key text not null unique,
  segments jsonb not null check (jsonb_typeof(segments)='array'),
  uploaded_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  foreign key (workspace_id,diagnostic_id) references contract_proof.diagnostics(workspace_id,id),
  unique (workspace_id,diagnostic_id,id),
  unique (workspace_id,diagnostic_id,sha256),
  check (object_key like workspace_id::text || '/' || diagnostic_id::text || '/' || id::text || '.%')
);
create table contract_proof.extractions (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null,
  diagnostic_id uuid not null,
  document_id uuid not null,
  status text not null default 'running' check (status in ('running','completed','failed')),
  model text not null,
  response_ids jsonb not null default '[]',
  warnings jsonb not null default '[]',
  error_code text,
  started_by uuid not null default auth.uid() references auth.users(id),
  created_at timestamptz not null default now(),
  finished_at timestamptz,
  foreign key (workspace_id,diagnostic_id,document_id)
    references contract_proof.documents(workspace_id,diagnostic_id,id),
  unique (workspace_id,diagnostic_id,id)
);
create unique index one_extraction_per_document on contract_proof.extractions(document_id)
  where status in ('running','completed');

create table contract_proof.rules (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null,
  diagnostic_id uuid not null,
  document_id uuid not null,
  extraction_id uuid,
  payload jsonb not null check (jsonb_typeof(payload)='object'),
  evidence jsonb not null check (jsonb_typeof(evidence)='array' and jsonb_array_length(evidence)>0),
  confidence numeric(7,6) not null check (confidence between 0 and 1),
  status text not null default 'candidate' check (status in ('candidate','approved','rejected')),
  version integer not null default 1 check (version>0),
  reviewer_id uuid references auth.users(id),
  review_note text,
  created_at timestamptz not null default now(),
  foreign key (workspace_id,diagnostic_id,document_id)
    references contract_proof.documents(workspace_id,diagnostic_id,id),
  foreign key (workspace_id,diagnostic_id,extraction_id)
    references contract_proof.extractions(workspace_id,diagnostic_id,id),
  unique (workspace_id,diagnostic_id,id),
  check (status='candidate' or (reviewer_id is not null and length(review_note)>=3))
);
create table contract_proof.invoice_lines (
  like contract_proof.rules including defaults including constraints including indexes,
  foreign key (workspace_id,diagnostic_id,document_id)
    references contract_proof.documents(workspace_id,diagnostic_id,id),
  foreign key (workspace_id,diagnostic_id,extraction_id)
    references contract_proof.extractions(workspace_id,diagnostic_id,id),
  foreign key (reviewer_id) references auth.users(id)
);
create table contract_proof.findings (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null,
  diagnostic_id uuid not null,
  invoice_line_id uuid not null,
  payload jsonb not null check (jsonb_typeof(payload)='object'),
  status text not null default 'Potential' check (status in ('Potential','Validated','Rejected')),
  recovery_status text not null default 'Identified' check (recovery_status in
    ('Identified','Under Review','Supplier Query','Credit Note Pending','Recovered','Rejected')),
  recovered_amount numeric(14,2),
  recovery_evidence jsonb not null default '[]',
  version integer not null default 1 check (version>0),
  reviewer_id uuid references auth.users(id),
  review_note text,
  created_at timestamptz not null default now(),
  foreign key (workspace_id,diagnostic_id,invoice_line_id)
    references contract_proof.invoice_lines(workspace_id,diagnostic_id,id),
  unique (diagnostic_id,invoice_line_id),
  check (status <> 'Potential' or recovery_status='Identified'),
  check (status <> 'Rejected' or recovery_status='Rejected'),
  check (status='Potential' or (reviewer_id is not null and length(review_note)>=3)),
  check (recovery_status <> 'Recovered' or (status='Validated' and recovered_amount>0
    and recovered_amount <= (payload->>'difference')::numeric
    and jsonb_array_length(recovery_evidence)>0))
);
create table contract_proof.audit_logs (
  id bigint generated always as identity primary key,
  workspace_id uuid not null references contract_proof.workspaces(id),
  actor_id uuid references auth.users(id),
  action text not null,
  entity_id uuid,
  before_value jsonb,
  after_value jsonb,
  created_at timestamptz not null default clock_timestamp()
);

-- Authorisation is based on database memberships, never editable user_metadata.
alter table contract_proof.workspaces enable row level security;
alter table contract_proof.memberships enable row level security;
create policy workspace_read on contract_proof.workspaces for select to contract_api
  using (contract_proof.has_access(id));
create policy membership_read on contract_proof.memberships for select to contract_api
  using (contract_proof.has_access(workspace_id));
grant select on contract_proof.workspaces,contract_proof.memberships to contract_api;

do $$ declare t text; begin
  foreach t in array array['diagnostics','documents','extractions','rules','invoice_lines','findings','audit_logs'] loop
    execute format('alter table contract_proof.%I enable row level security',t);
    execute format('create policy tenant_read on contract_proof.%I for select to contract_api using (contract_proof.has_access(workspace_id))',t);
    execute format('grant select on contract_proof.%I to contract_api',t);
    execute format('create index on contract_proof.%I(workspace_id)',t);
  end loop;
  foreach t in array array['extractions','rules','invoice_lines','findings'] loop
    execute format('create policy analyst_insert on contract_proof.%I for insert to contract_api with check (contract_proof.has_access(workspace_id,true))',t);
    execute format('create policy analyst_update on contract_proof.%I for update to contract_api using (contract_proof.has_access(workspace_id,true)) with check (contract_proof.has_access(workspace_id,true))',t);
    execute format('grant insert,update on contract_proof.%I to contract_api',t);
  end loop;
end $$;
create policy diagnostic_insert on contract_proof.diagnostics for insert to contract_api
  with check (contract_proof.has_access(workspace_id) and created_by=auth.uid() and state='Draft');
create policy diagnostic_update on contract_proof.diagnostics for update to contract_api
  using (contract_proof.has_access(workspace_id,true))
  with check (contract_proof.has_access(workspace_id,true));
create policy document_insert on contract_proof.documents for insert to contract_api
  with check (contract_proof.has_access(workspace_id) and uploaded_by=auth.uid());
grant insert,update on contract_proof.diagnostics to contract_api;
grant insert on contract_proof.documents to contract_api;

create function contract_proof.guard_mutation() returns trigger language plpgsql
set search_path = '' as $$
declare s text;
begin
  if TG_OP='UPDATE' then
    if new.id<>old.id or new.workspace_id<>old.workspace_id
       or new.created_at<>old.created_at then
      raise exception 'Immutable identity' using errcode='23514';
    end if;
    if TG_TABLE_NAME<>'diagnostics' then
      if new.diagnostic_id<>old.diagnostic_id then
        raise exception 'Immutable diagnostic' using errcode='23514';
      end if;
    end if;
  end if;
  if TG_TABLE_NAME='diagnostics' then
    if old.state='Completed' or new.created_by<>old.created_by then
      raise exception 'Completed diagnostic is immutable' using errcode='23514';
    end if;
  elsif TG_TABLE_NAME in ('rules','invoice_lines','extractions','documents') then
    select state into s from contract_proof.diagnostics where id=new.diagnostic_id;
    if s<>'Draft' then
      if TG_TABLE_NAME='documents' then
        if new.kind not in ('payment_record','credit_note') then
          raise exception 'Diagnostic inputs are frozen' using errcode='23514';
        end if;
      else
        raise exception 'Diagnostic inputs are frozen' using errcode='23514';
      end if;
    end if;
  end if;
  if TG_TABLE_NAME in ('rules','invoice_lines') then
    if TG_OP='INSERT' and (new.status<>'candidate' or new.version<>1 or new.reviewer_id is not null) then
      raise exception 'New inputs must be candidates' using errcode='23514';
    elsif TG_OP='UPDATE' then
      if old.status<>'candidate' or new.version<>old.version+1 or new.reviewer_id is distinct from auth.uid()
         or new.document_id<>old.document_id or new.extraction_id is distinct from old.extraction_id
         or new.confidence<>old.confidence then
        raise exception 'Invalid review mutation' using errcode='23514';
      end if;
    end if;
  elsif TG_TABLE_NAME='findings' then
    if TG_OP='INSERT' and (new.status<>'Potential' or new.recovery_status<>'Identified'
                           or new.reviewer_id is not null or new.version<>1) then
      raise exception 'New findings must be Potential' using errcode='23514';
    elsif TG_OP='UPDATE' then
      if new.payload<>old.payload or new.invoice_line_id<>old.invoice_line_id
        or new.version<>old.version+1 or new.reviewer_id is distinct from auth.uid()
        or old.status='Rejected' or (old.status='Validated' and new.status<>'Validated') then
        raise exception 'Invalid finding mutation' using errcode='23514';
      end if;
      if old.status='Potential' and new.status not in ('Validated','Rejected') then
        raise exception 'A Potential finding requires a review decision' using errcode='23514';
      end if;
      if old.status='Validated' and not (
        (old.recovery_status='Identified' and new.recovery_status in ('Under Review','Rejected')) or
        (old.recovery_status='Under Review' and new.recovery_status in ('Supplier Query','Credit Note Pending','Recovered','Rejected')) or
        (old.recovery_status='Supplier Query' and new.recovery_status in ('Under Review','Credit Note Pending','Recovered','Rejected')) or
        (old.recovery_status='Credit Note Pending' and new.recovery_status in ('Supplier Query','Recovered','Rejected'))
      ) then
        raise exception 'Invalid recovery transition' using errcode='23514';
      end if;
    end if;
  end if;
  return new;
end $$;

-- Trigger-owned log writes are in the same transaction as every data mutation.
create function contract_proof.log_change() returns trigger language plpgsql security definer
set search_path = '' as $$
declare b jsonb; a jsonb;
begin
  if TG_OP='UPDATE' then b := to_jsonb(old); end if;
  a := to_jsonb(new);
  -- Avoid duplicating source text or entire diagnostic snapshots in audit events.
  b := b - 'segments' - 'results'; a := a - 'segments' - 'results';
  insert into contract_proof.audit_logs(workspace_id,actor_id,action,entity_id,before_value,after_value)
    values(new.workspace_id,auth.uid(),TG_TABLE_NAME || '.' || lower(TG_OP),new.id,b,a);
  return new;
end $$;
revoke all on function contract_proof.log_change() from public;
revoke all on function contract_proof.guard_mutation() from public;
do $$ declare t text; begin
  foreach t in array array['diagnostics','documents','extractions','rules','invoice_lines','findings'] loop
    execute format('create trigger write_audit after insert or update on contract_proof.%I for each row execute function contract_proof.log_change()',t);
    if t='diagnostics' then
      execute format('create trigger guard_change before update on contract_proof.%I for each row execute function contract_proof.guard_mutation()',t);
    else
      execute format('create trigger guard_change before insert or update on contract_proof.%I for each row execute function contract_proof.guard_mutation()',t);
    end if;
  end loop;
end $$;

create function contract_proof.log_export(w uuid, d uuid, fmt text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not contract_proof.has_access(w) or fmt not in ('pdf','xlsx')
    or not exists (select 1 from contract_proof.diagnostics where id=d and workspace_id=w) then
    raise exception 'Not permitted' using errcode='42501';
  end if;
  insert into contract_proof.audit_logs(workspace_id,actor_id,action,entity_id,after_value)
    values(w,auth.uid(),'evidence_pack.export',d,jsonb_build_object('format',fmt));
end $$;
revoke all on function contract_proof.log_export(uuid,uuid,text) from public;
grant execute on function contract_proof.log_export(uuid,uuid,text) to contract_api;

-- No runtime role can mutate audit logs or membership assignments.
revoke all on all tables in schema contract_proof from anon,authenticated;
revoke all on all sequences in schema contract_proof from public,anon,authenticated,contract_api;
