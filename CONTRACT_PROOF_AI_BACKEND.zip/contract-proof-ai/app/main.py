from contextlib import asynccontextmanager

import httpx
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from psycopg import errors
from starlette.middleware.trustedhost import TrustedHostMiddleware
from starlette.responses import JSONResponse

from app.auth import SupabaseAuth
from app.config import get_settings
from app.db import Database
from app.errors import DomainError
from app.extraction import Extractor
from app.middleware import BodyLimitMiddleware, RateLimiter
from app.routes import router
from app.storage import Storage


def create_app(
    settings=None, *, database=None, auth=None, storage=None, extractor=None, http_client=None
):
    settings = settings or get_settings()
    client = http_client or httpx.Client(
        timeout=httpx.Timeout(40, connect=10), follow_redirects=False
    )
    db = database or Database(settings)
    extract = extractor or Extractor(settings)

    @asynccontextmanager
    async def lifespan(application):
        db.open()
        try:
            yield
        finally:
            db.close()
            client.close()
            extract.close()

    application = FastAPI(
        title="Contract Proof AI",
        version="0.1.0",
        lifespan=lifespan,
        description="Human-reviewed contract audit. No supplier contact or payment actions.",
        docs_url="/docs" if settings.environment == "development" else None,
        redoc_url=None,
        openapi_url="/openapi.json" if settings.environment == "development" else None,
    )
    application.state.settings = settings
    application.state.db = db
    application.state.auth = auth or SupabaseAuth(settings, client)
    application.state.storage = storage or Storage(settings, client)
    application.state.extractor = extract
    application.state.limiter = RateLimiter()
    application.add_middleware(BodyLimitMiddleware, max_upload_bytes=settings.max_upload_bytes)
    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=False,
        allow_methods=["GET", "POST", "PATCH"],
        allow_headers=["Authorization", "Content-Type"],
        expose_headers=["Content-Disposition"],
    )
    application.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.trusted_hosts)

    @application.exception_handler(DomainError)
    async def domain_error(request: Request, exc: DomainError):
        headers = {"WWW-Authenticate": "Bearer"} if exc.status == 401 else {}
        return JSONResponse({"detail": exc.message}, status_code=exc.status, headers=headers)

    @application.exception_handler(RequestValidationError)
    async def validation_error(request: Request, exc: RequestValidationError):
        # Validation responses must not echo passwords, tokens or document contents.
        return JSONResponse(
            {
                "detail": [
                    {"loc": e["loc"], "type": e["type"], "msg": e["msg"]} for e in exc.errors()
                ]
            },
            status_code=422,
        )

    @application.exception_handler(errors.IntegrityError)
    async def conflict(request: Request, exc):
        return JSONResponse(
            {"detail": "Data conflict or invalid workflow transition; reload the record"},
            status_code=409,
        )

    @application.exception_handler(errors.InsufficientPrivilege)
    async def forbidden(request: Request, exc):
        return JSONResponse({"detail": "Action not permitted"}, status_code=403)

    @application.exception_handler(errors.LockNotAvailable)
    async def busy(request: Request, exc):
        return JSONResponse({"detail": "Diagnostic is busy; retry the request"}, status_code=409)

    application.include_router(router)
    return application
