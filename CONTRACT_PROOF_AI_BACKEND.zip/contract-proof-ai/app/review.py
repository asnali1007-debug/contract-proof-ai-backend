from decimal import Decimal

from app.engine import calculate_line
from app.errors import DomainError


def review_candidate(row: dict, decision, actor_id: str, rules: list[dict] | None = None) -> dict:
    if row["version"] != decision.expected_version:
        raise DomainError("This item changed; reload it before reviewing", 409)
    if row["status"] != "candidate":
        raise DomainError(
            "Decided items are immutable; create a corrected candidate before running", 409
        )
    payload = decision.payload.model_dump(mode="json") if decision.payload else row["payload"]
    evidence = (
        [x.model_dump(mode="json") for x in decision.evidence]
        if decision.evidence is not None
        else row["evidence"]
    )
    if decision.decision == "reject" and (
        decision.payload is not None or decision.evidence is not None
    ):
        raise DomainError("Reject cannot also edit the item")
    if decision.decision == "edit" and decision.payload is None and decision.evidence is None:
        raise DomainError("Edit requires updated payload or evidence")
    result = {
        **row,
        "payload": payload,
        "evidence": evidence,
        "status": {"approve": "approved", "edit": "candidate", "reject": "rejected"}[
            decision.decision
        ],
        "version": row["version"] + 1,
        "reviewer_id": actor_id,
        "review_note": decision.note,
    }
    if rules is not None and decision.decision == "approve":
        calculate_line(result, rules)
    return result


def decide_finding(row: dict, decision, actor_id: str) -> dict:
    if row["version"] != decision.expected_version or row["status"] != "Potential":
        raise DomainError("Finding already decided or changed; reload it", 409)
    return {
        **row,
        "status": "Validated" if decision.decision == "validate" else "Rejected",
        "recovery_status": "Identified" if decision.decision == "validate" else "Rejected",
        "version": row["version"] + 1,
        "reviewer_id": actor_id,
        "review_note": decision.note,
    }


TRANSITIONS = {
    "Identified": {"Under Review", "Rejected"},
    "Under Review": {"Supplier Query", "Credit Note Pending", "Recovered", "Rejected"},
    "Supplier Query": {"Under Review", "Credit Note Pending", "Recovered", "Rejected"},
    "Credit Note Pending": {"Supplier Query", "Recovered", "Rejected"},
    "Recovered": set(),
    "Rejected": set(),
}


def change_recovery(row: dict, decision, actor_id: str) -> dict:
    if row["version"] != decision.expected_version:
        raise DomainError("Finding changed; reload it", 409)
    if row["status"] != "Validated":
        raise DomainError("Only a human-validated finding can progress in recovery", 409)
    if decision.status not in TRANSITIONS[row["recovery_status"]]:
        raise DomainError("Recovery transition is not allowed", 409)
    if decision.status == "Recovered":
        delta = Decimal(row["payload"]["difference"])
        if (
            not decision.evidence
            or decision.recovered_amount is None
            or not Decimal("0") < decision.recovered_amount <= delta
        ):
            raise DomainError(
                "Recovery needs source evidence and an amount above zero up to the overcharge"
            )
    elif decision.recovered_amount is not None:
        raise DomainError("Set recovered_amount only when recording a recovery")
    return {
        **row,
        "recovery_status": decision.status,
        "review_note": decision.note,
        "reviewer_id": actor_id,
        "version": row["version"] + 1,
        "recovered_amount": decision.recovered_amount,
        "recovery_evidence": [x.model_dump(mode="json") for x in decision.evidence],
    }
