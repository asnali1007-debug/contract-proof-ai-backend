"""Bounded, non-executing document text extraction with stable source locators."""

import csv
import io
import json
import re
import subprocess
import sys
import zipfile
from pathlib import PurePath

from app.errors import DomainError

MIME = {
    ".pdf": "application/pdf",
    ".csv": "text/csv",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}


def validate_upload(
    filename: str, mime: str | None, data: bytes, max_bytes: int
) -> tuple[str, str]:
    if not data or len(data) > max_bytes:
        raise DomainError("File is empty or exceeds the upload size limit", 413)
    if (
        not filename
        or filename != PurePath(filename).name
        or "\\" in filename
        or len(filename) > 180
    ):
        raise DomainError("Invalid filename")
    if any(ord(c) < 32 for c in filename):
        raise DomainError("Invalid filename")
    ext = PurePath(filename).suffix.lower()
    if ext not in MIME:
        raise DomainError("Supported formats: PDF, UTF-8 CSV and XLSX", 415)
    supplied = (mime or "application/octet-stream").split(";")[0].lower()
    allowed = {MIME[ext], "application/octet-stream"}
    if ext == ".csv":
        allowed |= {"application/vnd.ms-excel", "text/plain"}
    if supplied not in allowed:
        raise DomainError("Content type does not match the file extension", 415)
    if ext == ".pdf" and not data.startswith(b"%PDF-"):
        raise DomainError("Invalid PDF signature", 415)
    if ext == ".xlsx" and not data.startswith(b"PK\x03\x04"):
        raise DomainError("Invalid XLSX signature", 415)
    return ext, MIME[ext]


def parse_file(data: bytes, ext: str, max_chars=400000) -> list[dict]:
    segments, total = [], 0

    def add(identifier, text, **locator):
        nonlocal total
        text = str(text).strip()
        if not text:
            return
        total += len(text)
        if total > max_chars or len(segments) >= 20000:
            raise DomainError("Document text exceeds parser limits; split the file")
        # Bounded segments are all retained; never silently truncate source content.
        for part, start in enumerate(range(0, len(text), 6000), 1):
            segments.append(
                {"id": f"{identifier}:{part}", "text": text[start : start + 6000], **locator}
            )

    try:
        if ext == ".pdf":
            from pypdf import PdfReader

            reader = PdfReader(io.BytesIO(data), strict=True)
            if reader.is_encrypted or len(reader.pages) > 250:
                raise DomainError("Encrypted PDFs or PDFs above 250 pages require preparation")
            root = reader.trailer["/Root"]
            if (
                root.get("/OpenAction")
                or root.get("/AA")
                or root.get("/Names", {}).get("/JavaScript")
            ):
                raise DomainError("Active PDF content is not accepted")
            for page, item in enumerate(reader.pages, 1):
                text = item.extract_text() or ""
                if not text.strip():
                    raise DomainError(
                        "PDF contains a page without readable text; OCR it and upload again"
                    )
                add(f"page:{page}", text, page=page)
        elif ext == ".xlsx":
            from openpyxl import load_workbook

            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                files = archive.infolist()
                if len(files) > 2000 or sum(f.file_size for f in files) > 40 * 1024 * 1024:
                    raise DomainError("XLSX expanded size exceeds limit")
                if any(
                    f.file_size > 10 * 1024 * 1024 or f.file_size / max(f.compress_size, 1) > 500
                    for f in files
                ):
                    raise DomainError("XLSX compression exceeds safe limits")
                names = {f.filename.lower() for f in files}
                if "xl/workbook.xml" not in names or any(
                    "vbaproject" in n or "externallinks/" in n for n in names
                ):
                    raise DomainError(
                        "Macros, external links or invalid workbooks are not accepted"
                    )
            workbook = load_workbook(
                io.BytesIO(data), read_only=True, data_only=False, keep_links=False
            )
            try:
                if len(workbook.worksheets) > 30:
                    raise DomainError("XLSX has too many worksheets")
                for sheet in workbook:
                    if (sheet.max_row or 0) > 20000 or (sheet.max_column or 0) > 200:
                        raise DomainError(
                            "XLSX dimensions exceed limits; remove excess empty formatting"
                        )
                    for row_num, row in enumerate(sheet.iter_rows(), 1):
                        if any(c.data_type == "f" for c in row):
                            raise DomainError(
                                "Export Excel formula cells as values or CSV before uploading"
                            )
                        add(
                            f"sheet:{sheet.title}:row:{row_num}",
                            " | ".join(
                                f"{c.column_letter}={c.value}" for c in row if c.value is not None
                            ),
                            sheet=sheet.title,
                            row=row_num,
                        )
            finally:
                workbook.close()
        elif ext == ".csv":
            text = data.decode("utf-8-sig")
            if "\x00" in text:
                raise DomainError("CSV contains binary data", 415)
            csv.field_size_limit(20000)
            rows = csv.reader(io.StringIO(text), strict=True)
            headers = next(rows, None)
            if not headers or len(headers) > 200:
                raise DomainError("CSV requires a header row with at most 200 columns")
            add("csv:row:1", " | ".join(headers), row=1)
            for row_num, row in enumerate(rows, 2):
                if len(row) != len(headers):
                    raise DomainError(f"CSV row {row_num} has a different number of columns")
                add(
                    f"csv:row:{row_num}",
                    " | ".join(f"{h}={v}" for h, v in zip(headers, row, strict=True)),
                    row=row_num,
                )
        else:
            raise DomainError("Unsupported file format", 415)
    except DomainError:
        raise
    except Exception as exc:
        raise DomainError("File is malformed or could not be parsed", 415) from exc
    if not segments:
        raise DomainError("No readable text was found")
    return segments


def parse_isolated(data: bytes, ext: str, max_chars: int):
    try:
        result = subprocess.run(
            [sys.executable, "-m", "app.parsers", ext, str(max_chars)],
            input=data,
            capture_output=True,
            timeout=30,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise DomainError("Document parsing exceeded time limit; split the file", 422) from exc
    if result.returncode or not result.stdout:
        raise DomainError("Document exceeded parser resources or is malformed", 422)
    body = json.loads(result.stdout)
    if "error" in body:
        raise DomainError(body["error"], body["status"])
    return body["segments"]


def normalise(text):
    return re.sub(r"\s+", " ", text).strip()


def validate_evidence(evidence: list[dict], documents: dict[str, dict]):
    if not evidence:
        raise DomainError("Evidence is required")
    for item in evidence:
        doc = documents.get(str(item["document_id"]))
        if doc is None:
            raise DomainError("Evidence document must belong to this diagnostic")
        segments = {s["id"]: s for s in doc["segments"]}
        segment = segments.get(item["segment_id"])
        if segment is None or normalise(item["quote"]) not in normalise(segment["text"]):
            raise DomainError("Evidence quote must match the referenced source segment")


if __name__ == "__main__":
    try:
        import resource

        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024, 512 * 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_CPU, (20, 20))
    except ImportError:
        pass  # Linux container is recommended; Windows still has a wall-clock timeout.
    try:
        print(
            json.dumps(
                {
                    "segments": parse_file(
                        sys.stdin.buffer.read(20971521), sys.argv[1], int(sys.argv[2])
                    )
                }
            )
        )
    except DomainError as error:
        print(json.dumps({"error": error.message, "status": error.status}))
