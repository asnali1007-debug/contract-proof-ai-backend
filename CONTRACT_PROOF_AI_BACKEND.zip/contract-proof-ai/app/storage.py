from urllib.parse import quote

import httpx

from app.errors import DomainError


class Storage:
    def __init__(self, settings, client: httpx.Client):
        self.url = settings.supabase_url.rstrip("/") + "/storage/v1"
        self.bucket = settings.storage_bucket
        self.writer_key = settings.supabase_service_role_key.get_secret_value()
        self.reader_key = settings.supabase_anon_key.get_secret_value()
        self.client = client

    def _request(self, method, path, *, writer=False, token=None, **kwargs):
        key = self.writer_key if writer else self.reader_key
        headers = {"apikey": key, "Authorization": "Bearer " + (key if writer else token)}
        headers.update(kwargs.pop("headers", {}))
        try:
            response = self.client.request(method, self.url + path, headers=headers, **kwargs)
        except httpx.HTTPError as exc:
            raise DomainError("Document storage unavailable", 503) from exc
        if response.is_error:
            raise DomainError("Document storage request failed", 503)
        return response

    def upload(self, key, content, mime):
        self._request(
            "POST",
            f"/object/{quote(self.bucket)}/{quote(key, safe='/')}",
            writer=True,
            content=content,
            headers={"Content-Type": mime, "x-upsert": "false"},
        )

    def delete(self, key):
        self._request(
            "DELETE", f"/object/{quote(self.bucket)}", writer=True, json={"prefixes": [key]}
        )

    def download(self, key, token):
        # Reads use the caller's token so Storage RLS independently checks membership.
        return self._request(
            "GET", f"/object/authenticated/{quote(self.bucket)}/{quote(key, safe='/')}", token=token
        ).content
