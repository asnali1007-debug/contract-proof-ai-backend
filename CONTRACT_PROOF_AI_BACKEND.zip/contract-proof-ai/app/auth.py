from dataclasses import dataclass
from typing import Annotated
from uuid import UUID

import httpx
from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.errors import DomainError

bearer = HTTPBearer(auto_error=False)


@dataclass(frozen=True)
class Principal:
    id: UUID
    email: str | None
    token: str


class SupabaseAuth:
    def __init__(self, settings, client: httpx.Client):
        self.url = settings.supabase_url.rstrip("/") + "/auth/v1"
        self.key = settings.supabase_anon_key.get_secret_value()
        self.client = client

    def request(self, method, path, *, token=None, payload=None):
        headers = {"apikey": self.key}
        if token:
            headers["Authorization"] = "Bearer " + token
        try:
            response = self.client.request(method, self.url + path, headers=headers, json=payload)
        except httpx.HTTPError as exc:
            raise DomainError("Authentication service unavailable", 503) from exc
        if response.status_code in (400, 401, 403, 422):
            raise DomainError("Invalid credentials or expired session", 401)
        if response.status_code == 429:
            raise DomainError("Authentication rate limit reached", 429)
        if response.is_error:
            raise DomainError("Authentication service unavailable", 503)
        return response.json() if response.content else {}

    def verify(self, token):
        # The project's Auth server verifies token signature, expiry and user identity.
        # Never decode an unsigned JWT or trust user-supplied role metadata.
        user = self.request("GET", "/user", token=token)
        try:
            return Principal(UUID(user["id"]), user.get("email"), token)
        except (KeyError, ValueError) as exc:
            raise DomainError("Invalid authentication response", 401) from exc


def current_user(
    request: Request, credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)]
):
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise DomainError("Bearer access token required", 401)
    return request.app.state.auth.verify(credentials.credentials)
