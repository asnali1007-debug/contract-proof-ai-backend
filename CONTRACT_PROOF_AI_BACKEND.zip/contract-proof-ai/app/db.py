import json
from contextlib import contextmanager

from psycopg import sql
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb
from psycopg_pool import ConnectionPool

from app.errors import DomainError

TABLES = {
    "workspaces",
    "memberships",
    "diagnostics",
    "documents",
    "extractions",
    "rules",
    "invoice_lines",
    "findings",
    "audit_logs",
}
JSON_COLUMNS = {
    "payload",
    "evidence",
    "segments",
    "results",
    "warnings",
    "response_ids",
    "recovery_evidence",
}


class Database:
    def __init__(self, settings):
        self.pool = ConnectionPool(
            settings.database_url.get_secret_value(),
            min_size=1,
            max_size=settings.db_pool_size,
            open=False,
            kwargs={"row_factory": dict_row, "prepare_threshold": None},
        )

    def open(self):
        self.pool.open(wait=True, timeout=15)
        with self.pool.connection() as conn:
            role = conn.execute(
                "select current_user as name, rolsuper, rolbypassrls, rolcreaterole "
                "from pg_roles where rolname=current_user"
            ).fetchone()
            if role["name"] != "contract_api" or any(
                role[k] for k in ("rolsuper", "rolbypassrls", "rolcreaterole")
            ):
                raise RuntimeError("DATABASE_URL must use the restricted contract_api role")
            elevated = conn.execute(
                "select 1 from pg_auth_members where member=(select oid from pg_roles where rolname=current_user)"
            ).fetchone()
            owns = conn.execute(
                "select 1 from pg_class c join pg_namespace n on n.oid=c.relnamespace "
                "where n.nspname='contract_proof' and c.relowner=(select oid from pg_roles where rolname=current_user) limit 1"
            ).fetchone()
            if elevated or owns:
                raise RuntimeError(
                    "contract_api must not own tables or inherit other database roles"
                )

    def close(self):
        self.pool.close()

    @contextmanager
    def transaction(self, user_id):
        with self.pool.connection() as conn, conn.transaction():
            conn.execute(
                "select set_config('request.jwt.claims',%s,true)",
                (json.dumps({"sub": str(user_id), "role": "authenticated"}),),
            )
            conn.execute("select set_config('statement_timeout','15000',true)")
            conn.execute("select set_config('lock_timeout','5000',true)")
            yield Repository(conn)


class Repository:
    def __init__(self, conn):
        self.conn = conn

    @staticmethod
    def table(name):
        if name not in TABLES:
            raise ValueError("Unsupported table")
        return sql.Identifier("contract_proof", name)

    def list(self, table, workspace_id=None, diagnostic_id=None, limit=200, offset=0, **filters):
        if workspace_id is not None:
            filters["workspace_id"] = workspace_id
        if diagnostic_id is not None:
            filters["diagnostic_id"] = diagnostic_id
        where = (
            sql.SQL(" and ").join(sql.SQL("{}=%s").format(sql.Identifier(k)) for k in filters)
            if filters
            else sql.SQL("true")
        )
        order = "user_id" if table == "memberships" else "id"
        query = sql.SQL("select * from {} where {} order by {} limit %s offset %s").format(
            self.table(table), where, sql.Identifier(order)
        )
        return self.conn.execute(query, [*filters.values(), limit, offset]).fetchall()

    def get(self, table, workspace_id, entity_id, lock=False):
        column = "id" if table == "workspaces" else "workspace_id"
        query = sql.SQL("select * from {} where {}=%s and id=%s{}").format(
            self.table(table), sql.Identifier(column), sql.SQL(" for update" if lock else "")
        )
        row = self.conn.execute(query, (workspace_id, entity_id)).fetchone()
        if row is None:
            raise DomainError("Record not found", 404)
        return row

    def require_access(self, workspace_id, analyst=False):
        if not self.conn.execute(
            "select contract_proof.has_access(%s,%s) as allowed", (workspace_id, analyst)
        ).fetchone()["allowed"]:
            # A nonexistent and an inaccessible workspace are indistinguishable.
            raise DomainError("Workspace not found or role not permitted", 404)

    def lock_diagnostic(self, workspace_id, diagnostic_id, draft=True):
        # Advisory locks let clients serialize uploads without giving them UPDATE
        # permission on diagnostic state. Every diagnostic mutation uses this lock.
        self.conn.execute(
            "select pg_advisory_xact_lock(hashtextextended(%s,0))",
            (f"{workspace_id}/{diagnostic_id}",),
        )
        row = self.get("diagnostics", workspace_id, diagnostic_id)
        if draft and row["state"] != "Draft":
            raise DomainError("Diagnostic is complete and its calculation inputs are frozen", 409)
        return row

    def insert(self, table, **fields):
        keys = list(fields)
        query = sql.SQL("insert into {} ({}) values ({}) returning *").format(
            self.table(table),
            sql.SQL(",").join(map(sql.Identifier, keys)),
            sql.SQL(",").join(sql.Placeholder() for _ in keys),
        )
        return self.conn.execute(
            query, [Jsonb(v) if k in JSON_COLUMNS else v for k, v in fields.items()]
        ).fetchone()

    def update(self, table, workspace_id, entity_id, **fields):
        query = sql.SQL("update {} set {} where workspace_id=%s and id=%s returning *").format(
            self.table(table),
            sql.SQL(",").join(sql.SQL("{}=%s").format(sql.Identifier(k)) for k in fields),
        )
        row = self.conn.execute(
            query,
            [
                *[Jsonb(v) if k in JSON_COLUMNS else v for k, v in fields.items()],
                workspace_id,
                entity_id,
            ],
        ).fetchone()
        if row is None:
            raise DomainError("Record not found", 404)
        return row

    def log_export(self, workspace_id, diagnostic_id, fmt):
        self.conn.execute(
            "select contract_proof.log_export(%s,%s,%s)", (workspace_id, diagnostic_id, fmt)
        )
