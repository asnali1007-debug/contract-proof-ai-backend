"""Evidence snapshots: PDF narrative and inert Excel values, never executable inputs."""

import io
import json
from decimal import Decimal
from pathlib import Path
from xml.sax.saxutils import escape

import reportlab
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

# Embed ReportLab's bundled fonts so viewers do not substitute inconsistent base fonts.
_fonts = Path(reportlab.__file__).parent / "fonts"
pdfmetrics.registerFont(TTFont("CPBody", str(_fonts / "Vera.ttf")))
pdfmetrics.registerFont(TTFont("CPBold", str(_fonts / "VeraBd.ttf")))

NOTICE = "Potential findings require internal human validation. This pack is not a legal conclusion or an instruction to withhold payment. Recovery statuses record human actions only. Amounts exclude VAT."


def evidence_rows(result, documents):
    items = [("Invoice", e) for e in result["line_snapshot"]["evidence"]]
    items += [("Approved hours", e) for e in result["line_snapshot"]["payload"]["hours_evidence"]]
    for rule in result["rule_snapshots"]:
        items += [(f"Rule {rule['id']} v{rule['version']}", e) for e in rule["evidence"]]
    output = []
    for purpose, evidence in items:
        doc = documents[str(evidence["document_id"])]
        segment = next(x for x in doc["segments"] if x["id"] == evidence["segment_id"])
        locator = (
            f"Page {segment['page']}"
            if "page" in segment
            else f"Sheet {segment.get('sheet', 'CSV')}, row {segment['row']}"
        )
        output.append(
            {
                "purpose": purpose,
                "document_id": str(doc["id"]),
                "filename": doc["filename"],
                "sha256": doc["sha256"],
                "locator": locator,
                "segment_id": segment["id"],
                "clause": evidence.get("clause") or "",
                "quote": evidence["quote"],
            }
        )
    return output


def _safe_cell(cell, value):
    if isinstance(value, str):
        # Explicit string cells stop =,+,-,@ inputs becoming Excel formulas or DDE.
        value = "".join(c for c in value if ord(c) >= 32 or c in "\t\n\r")
        cell.value = value
        cell.data_type = "s"
    else:
        cell.value = value


def xlsx_pack(diagnostic, findings, documents):
    wb = Workbook()
    summary = wb.active
    summary.title = "Read me"
    summary.append(["CONTRACT PROOF AI", "Evidence pack"])
    summary.append(["Diagnostic", str(diagnostic["id"])])
    summary.append(["Name", diagnostic["name"]])
    summary.append(["Scope", NOTICE])
    summary.append(
        [
            "Calculation",
            "Decimal arithmetic; line net rounded half-up to 2 decimal places. No currency conversion or VAT.",
        ]
    )
    summary.append(
        [
            "Confidence",
            "Minimum source extraction score. A heuristic, not the probability a finding is correct.",
        ]
    )
    result_sheet = wb.create_sheet("Calculations")
    result_sheet.append(
        [
            "Invoice",
            "Line",
            "Supplier",
            "Contract version",
            "Currency",
            "Expected",
            "Charged",
            "Difference",
            "Finding status",
            "Recovery status",
            "Recovered",
            "Calculation",
            "Confidence",
            "Invoice line ID",
        ]
    )
    evidence_sheet = wb.create_sheet("Evidence")
    evidence_sheet.append(
        [
            "Invoice line ID",
            "Purpose",
            "Document",
            "Document ID",
            "Page or row",
            "Clause",
            "Quote",
            "SHA-256",
            "Segment ID",
        ]
    )
    reviews = wb.create_sheet("Reviews")
    reviews.append(
        [
            "Finding ID",
            "Status",
            "Reviewer ID",
            "Decision note",
            "Record version",
            "Recovery evidence",
        ]
    )
    by_line = {str(x["invoice_line_id"]): x for x in findings}
    for result in diagnostic["results"]:
        finding = by_line.get(result["invoice_line_id"], {})
        result_sheet.append(
            [
                result["invoice_number"],
                result["line_number"],
                result["supplier"],
                result["contract_version"],
                result["currency"],
                Decimal(result["expected_amount"]),
                Decimal(result["charged_amount"]),
                Decimal(result["difference"]),
                finding.get("status", "Matched"),
                finding.get("recovery_status", ""),
                finding.get("recovered_amount"),
                result["calculation"]["expression"],
                Decimal(result["confidence"]["score"]),
                result["invoice_line_id"],
            ]
        )
        for e in evidence_rows(result, documents):
            evidence_sheet.append(
                [
                    result["invoice_line_id"],
                    e["purpose"],
                    e["filename"],
                    e["document_id"],
                    e["locator"],
                    e["clause"],
                    e["quote"],
                    e["sha256"],
                    e["segment_id"],
                ]
            )
        if finding:
            reviews.append(
                [
                    str(finding["id"]),
                    finding["status"],
                    str(finding["reviewer_id"] or ""),
                    finding.get("review_note") or "",
                    finding["version"],
                    json.dumps(finding.get("recovery_evidence", []), default=str),
                ]
            )
    for sheet in wb:
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        for row in sheet:
            for cell in row:
                _safe_cell(cell, cell.value)
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                if cell.row == 1:
                    cell.font = Font(color="FFFFFF", bold=True)
                    cell.fill = PatternFill("solid", fgColor="16302B")
        for col in sheet.columns:
            letter = col[0].column_letter
            sheet.column_dimensions[letter].width = min(
                65, max(16, max(len(str(c.value or "")) for c in col[:20]) + 2)
            )
    for row in result_sheet.iter_rows(min_row=2):
        for col in (5, 6, 7, 10):
            row[col].number_format = "#,##0.00"
        row[12].number_format = "0.00"
    summary.column_dimensions["B"].width = 100
    summary.row_dimensions[4].height = 60
    output = io.BytesIO()
    wb.save(output)
    return output.getvalue()


def pdf_pack(diagnostic, findings, documents):
    output = io.BytesIO()
    styles = getSampleStyleSheet()
    for name in ("Normal", "BodyText"):
        styles[name].fontName = "CPBody"
    for name in ("Title", "Heading2"):
        styles[name].fontName = "CPBold"
    styles.add(
        ParagraphStyle(
            name="EvidenceSmall",
            parent=styles["BodyText"],
            fontSize=8,
            leading=11,
            spaceAfter=5,
            splitLongWords=True,
        )
    )

    def p(value, style="BodyText"):
        return Paragraph(escape(str(value)), styles[style])

    story = [
        p("CONTRACT PROOF AI", "Title"),
        p("Contract-to-invoice evidence pack", "Heading2"),
        p(diagnostic["name"]),
        p(f"Diagnostic: {diagnostic['id']}", "EvidenceSmall"),
        p(NOTICE),
        Spacer(1, 0.15 * inch),
    ]
    by_line = {str(x["invoice_line_id"]): x for x in findings}
    for number, result in enumerate(diagnostic["results"], 1):
        finding = by_line.get(result["invoice_line_id"], {})
        story += [
            p(
                f"{number}. {result['supplier']} | Invoice {result['invoice_number']} | Line {result['line_number']}",
                "Heading2",
            ),
            p(
                f"Contract {result['contract_version']} | {result['service_date']} | {result['currency']}",
                "EvidenceSmall",
            ),
            p(
                f"Status: {finding.get('status', 'Matched')} | Recovery: {finding.get('recovery_status', 'Not applicable')}"
            ),
        ]
        table = Table(
            [
                ["Expected", "Charged", "Difference"],
                [result["expected_amount"], result["charged_amount"], result["difference"]],
            ],
            colWidths=[2.1 * inch] * 3,
        )
        table.setStyle(
            TableStyle(
                [
                    ("FONTNAME", (0, 0), (-1, -1), "CPBody"),
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#16302B")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
                    ("TOPPADDING", (0, 0), (-1, -1), 7),
                    ("GRID", (0, 0), (-1, -1), 0.3, colors.lightgrey),
                ]
            )
        )
        story += [
            Spacer(1, 6),
            table,
            Spacer(1, 8),
            p(result["calculation"]["expression"]),
            p(result["calculation"]["rounding"], "EvidenceSmall"),
            p(
                f"Confidence score {result['confidence']['score']}: {result['confidence']['basis']}",
                "EvidenceSmall",
            ),
        ]
        if finding.get("review_note"):
            story += [
                p(f"Reviewer: {finding['reviewer_id']} | {finding['review_note']}", "EvidenceSmall")
            ]
        if finding.get("recovered_amount") is not None:
            story += [p(f"Recorded recovery: {finding['recovered_amount']} {result['currency']}")]
        for e in evidence_rows(result, documents):
            story.append(
                KeepTogether(
                    [
                        p(
                            f"{e['purpose']} | {e['filename']} | {e['locator']} | Clause {e['clause'] or 'not specified'}",
                            "EvidenceSmall",
                        ),
                        p(e["quote"], "EvidenceSmall"),
                        p(f"Document {e['document_id']} | SHA-256 {e['sha256']}", "EvidenceSmall"),
                    ]
                )
            )
        for e in finding.get("recovery_evidence", []):
            story += [
                p(
                    f"Recovery evidence: document {e['document_id']}, {e['segment_id']} | {e['quote']}",
                    "EvidenceSmall",
                )
            ]
        story.append(Spacer(1, 12))

    def footer(canvas, doc):
        canvas.setFont("CPBody", 8)
        canvas.drawString(
            40, 25, "Contract Proof AI | Confidential | Human-reviewed audit workflow"
        )
        canvas.drawRightString(doc.pagesize[0] - 40, 25, f"Page {doc.page}")

    SimpleDocTemplate(output, leftMargin=40, rightMargin=40, topMargin=40, bottomMargin=45).build(
        story, onFirstPage=footer, onLaterPages=footer
    )
    return output.getvalue()
