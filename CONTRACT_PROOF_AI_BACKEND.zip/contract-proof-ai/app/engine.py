"""Pure Decimal arithmetic. No model, network, database, float or calendar inference."""

from decimal import ROUND_HALF_UP, Decimal, localcontext

from app.errors import DomainError
from app.models import InvoiceInput, RuleTerms

ENGINE_VERSION = "1.0.0"
PENNY = Decimal("0.01")


def money(value: Decimal) -> Decimal:
    return value.quantize(PENNY, rounding=ROUND_HALF_UP)


def calculate_line(line: dict, rules: list[dict]) -> dict:
    # Input limits can produce more than 28 significant digits before final rounding.
    with localcontext() as context:
        context.prec = 64
        return _calculate_line(line, rules)


def _calculate_line(line: dict, rules: list[dict]) -> dict:
    if line["status"] != "approved":
        raise DomainError("Invoice inputs must be approved before calculation", 409)
    data = InvoiceInput.model_validate(line["payload"])
    if not data.hours_evidence:
        raise DomainError("Approved hours require source evidence", 409)
    by_id = {str(r["id"]): r for r in rules}
    selected: list[dict] = []

    def applicable(terms: RuleTerms) -> bool:
        return (
            (terms.supplier, terms.contract_version, terms.service_code, terms.currency)
            == (data.supplier, data.contract_version, data.service_code, data.currency)
            and terms.effective_from <= data.service_date
            and (terms.effective_to is None or data.service_date <= terms.effective_to)
            and terms.band in ("all", data.band)
        )

    def select(rule_id, expected_kinds: set[str]) -> RuleTerms:
        row = by_id.get(str(rule_id))
        if not row or row["status"] != "approved":
            raise DomainError(
                "Every selected rule must exist and be approved in this diagnostic", 409
            )
        terms = RuleTerms.model_validate(row["payload"])
        if terms.kind not in expected_kinds or not applicable(terms):
            raise DomainError(
                "Rule does not match supplier, version, service, currency, band or date", 409
            )
        selected.append(row)
        return terms

    select(data.contract_rule_id, {"contract_version"})
    base = select(data.rate_rule_id, {"hourly_rate"})
    # Explicit selection does not make two contradictory active base rates safe.
    for kind in ("contract_version", "hourly_rate"):
        matching = [
            r
            for r in rules
            if r["status"] == "approved"
            and RuleTerms.model_validate(r["payload"]).kind == kind
            and applicable(RuleTerms.model_validate(r["payload"]))
        ]
        if len(matching) != 1:
            raise DomainError(f"Overlapping or missing approved {kind} rules require review", 409)
    multiplier = Decimal("1")
    if data.band != "regular" and not data.premium_rule_id:
        raise DomainError(
            "A non-regular band requires an explicit approved premium (including 1x)", 409
        )
    if data.premium_rule_id:
        multiplier = select(data.premium_rule_id, {"premium"}).value
    adjustments = [
        select(r, {"management_fee", "variation", "credit"}) for r in data.adjustment_rule_ids
    ]
    delta = sum((t.value for t in adjustments if t.basis == "rate_delta"), Decimal("0"))
    rate = base.value + delta
    if rate < 0:
        raise DomainError("Variations produce a negative rate; review the inputs", 409)
    labour = data.hours * rate * multiplier
    fixed = sum((t.value for t in adjustments if t.basis == "fixed"), Decimal("0"))
    percentage = sum((t.value for t in adjustments if t.basis == "percentage"), Decimal("0"))
    percentage_charge = labour * percentage / Decimal("100")
    credits = sum((t.value for t in adjustments if t.basis == "credit"), Decimal("0"))
    expected = money(labour + fixed + percentage_charge - credits)
    if expected < 0:
        raise DomainError(
            "Credits exceed this line's expected charges; allocate them for review", 409
        )
    charged = money(data.charged_amount)
    difference = money(charged - expected)
    confidence = min(
        [Decimal(str(line["confidence"]))] + [Decimal(str(r["confidence"])) for r in selected]
    )
    rule_snapshot = [
        {
            "id": str(r["id"]),
            "version": r["version"],
            "payload": r["payload"],
            "evidence": r["evidence"],
            "reviewer_id": str(r["reviewer_id"]),
        }
        for r in selected
    ]
    return {
        "engine_version": ENGINE_VERSION,
        "invoice_line_id": str(line["id"]),
        "supplier": data.supplier,
        "contract_version": data.contract_version,
        "service_code": data.service_code,
        "invoice_number": data.invoice_number,
        "line_number": data.line_number,
        "service_date": data.service_date.isoformat(),
        "currency": data.currency,
        "expected_amount": str(expected),
        "charged_amount": str(charged),
        "difference": str(difference),
        "classification": "Potential overcharge"
        if difference > 0
        else "Potential undercharge"
        if difference < 0
        else "Matched",
        "confidence": {
            "score": str(confidence),
            "basis": "Minimum input extraction score; not a probability or validation of the finding",
        },
        "calculation": {
            "formula": "hours * (base_rate + rate_variations) * premium + fixed_charges + labour * management_percent / 100 - credits",
            "hours": str(data.hours),
            "base_rate": str(base.value),
            "rate_variations": str(delta),
            "premium": str(multiplier),
            "labour": str(labour),
            "fixed_charges": str(fixed),
            "management_percent": str(percentage),
            "percentage_charge": str(percentage_charge),
            "credits": str(credits),
            "rounding": "Net line total, 2 decimal places, ROUND_HALF_UP",
            "expression": f"{data.hours} * ({base.value} + {delta}) * {multiplier} + {fixed} + {percentage_charge} - {credits} = {expected}",
        },
        "line_snapshot": {
            "id": str(line["id"]),
            "version": line["version"],
            "payload": line["payload"],
            "evidence": line["evidence"],
            "reviewer_id": str(line["reviewer_id"]),
        },
        "rule_snapshots": rule_snapshot,
    }


def calculate_diagnostic(lines: list[dict], rules: list[dict]) -> list[dict]:
    if any(x["status"] == "candidate" for x in lines + rules):
        raise DomainError(
            "Resolve all candidate rules and invoice lines before running the diagnostic", 409
        )
    approved = [x for x in lines if x["status"] == "approved"]
    if not approved:
        raise DomainError("At least one approved invoice line is required", 409)
    identities, once_only = set(), set()
    by_id = {str(x["id"]): x for x in rules}
    results = []
    for line in approved:
        data = InvoiceInput.model_validate(line["payload"])
        identity = (data.supplier, data.invoice_number, data.line_number)
        if identity in identities:
            raise DomainError("Duplicate supplier/invoice/line identity requires review", 409)
        identities.add(identity)
        result = calculate_line(line, rules)
        for rule_id in data.adjustment_rule_ids:
            rule = RuleTerms.model_validate(by_id[str(rule_id)]["payload"])
            if rule.basis in {"fixed", "credit"}:
                key = (rule.supplier, rule.currency, rule.kind, rule.reference or str(rule_id))
                if key in once_only:
                    raise DomainError(
                        "A credit or fixed-charge allocation cannot be used twice in one diagnostic",
                        409,
                    )
                once_only.add(key)
        results.append(result)
    return results
