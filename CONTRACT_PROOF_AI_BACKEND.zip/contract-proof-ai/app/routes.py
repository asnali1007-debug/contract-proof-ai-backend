import hashlib
import logging
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Annotated, Literal
from urllib.parse import quote
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, File, Form, Query, Request, UploadFile
from fastapi.responses import Response

from app.auth import Principal, current_user
from app.engine import calculate_diagnostic
from app.errors import DomainError
from app.exports import pdf_pack, xlsx_pack
from app.models import (
    CandidateLine,
    CandidateRule,
    DiagnosticCreate,
    DocumentKind,
    FindingDecision,
    LineDecision,
    Login,
    RecoveryDecision,
    Refresh,
    RuleDecision,
)
from app.parsers import parse_isolated, validate_evidence, validate_upload
from app.review import change_recovery, decide_finding, review_candidate

router = APIRouter()
User = Annotated[Principal, Depends(current_user)]
W = "/workspaces/{workspace_id}"
D = W + "/diagnostics/{diagnostic_id}"
logger = logging.getLogger("contract_proof")


@contextmanager
def transaction(request, user, workspace_id, analyst=False):
    request.app.state.limiter.check((str(user.id), "api"), 180)
    with request.app.state.db.transaction(user.id) as repo:
        repo.require_access(workspace_id, analyst)
        yield repo


def in_diagnostic(repo, table, workspace_id, diagnostic_id, entity_id):
    row = repo.get(table, workspace_id, entity_id)
    if row["diagnostic_id"] != diagnostic_id:
        raise DomainError("Record not found", 404)
    return row


def document_map(repo, workspace_id, diagnostic_id):
    docs = repo.list("documents", workspace_id, diagnostic_id, limit=1001)
    if len(docs) > 1000:
        raise DomainError("Too many documents in diagnostic; split the audit", 409)
    return {str(d["id"]): d for d in docs}


def check_sources(row, docs, table):
    validate_evidence(row["evidence"], docs)
    if table == "invoice_lines":
        if any(docs[str(e["document_id"])]["kind"] != "invoice" for e in row["evidence"]):
            raise DomainError("Invoice lines must cite invoice documents")
        hours = row["payload"].get("hours_evidence", [])
        if hours:
            validate_evidence(hours, docs)
    else:
        permitted = (
            {"credit_note"} if row["payload"]["kind"] == "credit" else {"contract", "rate_card"}
        )
        if any(docs[str(e["document_id"])]["kind"] not in permitted for e in row["evidence"]):
            raise DomainError(
                "Rule evidence must come from contract/rate-card documents or credit notes for credits"
            )


@router.get("/health", tags=["Operations"])
def health():
    return {"status": "ok", "service": "contract-proof-ai"}


@router.post("/auth/login", tags=["Authentication"])
def login(data: Login, request: Request):
    request.app.state.limiter.check((request.client.host, "auth"), 10)
    result = request.app.state.auth.request(
        "POST", "/token?grant_type=password", payload=data.model_dump()
    )
    return {
        k: result.get(k)
        for k in ("access_token", "refresh_token", "token_type", "expires_in", "expires_at")
    }


@router.post("/auth/refresh", tags=["Authentication"])
def refresh(data: Refresh, request: Request):
    request.app.state.limiter.check((request.client.host, "auth"), 10)
    result = request.app.state.auth.request(
        "POST", "/token?grant_type=refresh_token", payload=data.model_dump()
    )
    return {
        k: result.get(k)
        for k in ("access_token", "refresh_token", "token_type", "expires_in", "expires_at")
    }


@router.post("/auth/logout", tags=["Authentication"], status_code=204)
def logout(request: Request, user: User):
    request.app.state.auth.request("POST", "/logout?scope=local", token=user.token)


@router.get("/auth/me", tags=["Authentication"])
def me(user: User):
    return {"id": user.id, "email": user.email}


@router.get("/workspaces", tags=["Workspaces"])
def workspaces(request: Request, user: User, offset: Annotated[int, Query(ge=0)] = 0):
    with request.app.state.db.transaction(user.id) as repo:
        return repo.list("workspaces", limit=100, offset=offset)


@router.get(W + "/memberships", tags=["Workspaces"])
def memberships(workspace_id: UUID, request: Request, user: User):
    with transaction(request, user, workspace_id) as repo:
        return repo.list("memberships", workspace_id, limit=200)


@router.post(W + "/diagnostics", tags=["Diagnostics"], status_code=201)
def create_diagnostic(workspace_id: UUID, data: DiagnosticCreate, request: Request, user: User):
    with transaction(request, user, workspace_id) as repo:
        return repo.insert(
            "diagnostics", workspace_id=workspace_id, name=data.name, created_by=user.id
        )


@router.get(W + "/diagnostics", tags=["Diagnostics"])
def list_diagnostics(
    workspace_id: UUID, request: Request, user: User, offset: Annotated[int, Query(ge=0)] = 0
):
    with transaction(request, user, workspace_id) as repo:
        return repo.list("diagnostics", workspace_id, limit=100, offset=offset)


@router.get(D, tags=["Diagnostics"])
def get_diagnostic(workspace_id: UUID, diagnostic_id: UUID, request: Request, user: User):
    with transaction(request, user, workspace_id) as repo:
        return repo.get("diagnostics", workspace_id, diagnostic_id)


@router.post(D + "/documents", tags=["Documents"], status_code=201)
def upload(
    workspace_id: UUID,
    diagnostic_id: UUID,
    request: Request,
    user: User,
    kind: Annotated[DocumentKind, Form()],
    file: Annotated[UploadFile, File()],
):
    request.app.state.limiter.check((str(user.id), "upload"), 20)
    settings = request.app.state.settings
    # Authorise before spending parsing resources or touching privileged Storage.
    with transaction(request, user, workspace_id) as repo:
        diagnostic = repo.get("diagnostics", workspace_id, diagnostic_id)
        if diagnostic["state"] != "Draft" and kind not in {"payment_record", "credit_note"}:
            raise DomainError(
                "Only recovery evidence can be uploaded after a diagnostic completes", 409
            )
    try:
        data = file.file.read(settings.max_upload_bytes + 1)
        ext, mime = validate_upload(
            file.filename, file.content_type, data, settings.max_upload_bytes
        )
    finally:
        file.file.close()
    segments = parse_isolated(data, ext, settings.max_text_chars)
    digest = hashlib.sha256(data).hexdigest()
    document_id = uuid4()
    key = f"{workspace_id}/{diagnostic_id}/{document_id}{ext}"
    stored = False
    try:
        with transaction(request, user, workspace_id) as repo:
            repo.lock_diagnostic(
                workspace_id, diagnostic_id, draft=kind not in {"payment_record", "credit_note"}
            )
            if repo.list("documents", workspace_id, diagnostic_id, sha256=digest, limit=1):
                raise DomainError("This exact file is already uploaded to this diagnostic", 409)
            if len(repo.list("documents", workspace_id, diagnostic_id, limit=1001)) >= 1000:
                raise DomainError("Document limit reached; create a separate diagnostic", 409)
            request.app.state.storage.upload(key, data, mime)
            stored = True
            result = repo.insert(
                "documents",
                id=document_id,
                workspace_id=workspace_id,
                diagnostic_id=diagnostic_id,
                kind=kind,
                filename=file.filename,
                media_type=mime,
                byte_size=len(data),
                sha256=digest,
                object_key=key,
                segments=segments,
                uploaded_by=user.id,
            )
        return {k: v for k, v in result.items() if k not in {"segments", "object_key"}}
    except Exception:
        if stored:
            try:
                request.app.state.storage.delete(key)
            except Exception:
                logger.error("orphan_upload_cleanup_required document_id=%s", document_id)
        raise


@router.get(D + "/documents", tags=["Documents"])
def list_documents(
    workspace_id: UUID,
    diagnostic_id: UUID,
    request: Request,
    user: User,
    offset: Annotated[int, Query(ge=0)] = 0,
):
    with transaction(request, user, workspace_id) as repo:
        repo.get("diagnostics", workspace_id, diagnostic_id)
        rows = repo.list("documents", workspace_id, diagnostic_id, limit=100, offset=offset)
        return [{k: v for k, v in r.items() if k not in {"segments", "object_key"}} for r in rows]


@router.get(D + "/documents/{document_id}", tags=["Documents"])
def get_document(
    workspace_id: UUID, diagnostic_id: UUID, document_id: UUID, request: Request, user: User
):
    with transaction(request, user, workspace_id) as repo:
        row = in_diagnostic(repo, "documents", workspace_id, diagnostic_id, document_id)
        return {k: v for k, v in row.items() if k != "object_key"}


@router.get(D + "/documents/{document_id}/download", tags=["Documents"])
def download(
    workspace_id: UUID, diagnostic_id: UUID, document_id: UUID, request: Request, user: User
):
    with transaction(request, user, workspace_id) as repo:
        row = in_diagnostic(repo, "documents", workspace_id, diagnostic_id, document_id)
    content = request.app.state.storage.download(row["object_key"], user.token)
    if hashlib.sha256(content).hexdigest() != row["sha256"]:
        raise DomainError("Document integrity check failed", 409)
    return Response(
        content,
        media_type=row["media_type"],
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(row['filename'])}"},
    )


@router.post(D + "/documents/{document_id}/extract", tags=["Extraction"], status_code=201)
def extract(
    workspace_id: UUID, diagnostic_id: UUID, document_id: UUID, request: Request, user: User
):
    request.app.state.limiter.check((str(user.id), "extract"), 4)
    with transaction(request, user, workspace_id, analyst=True) as repo:
        repo.lock_diagnostic(workspace_id, diagnostic_id)
        document = in_diagnostic(repo, "documents", workspace_id, diagnostic_id, document_id)
        if document["kind"] in {"payment_record", "timesheet"}:
            raise DomainError(
                "This document is supporting evidence; select its source segments during review"
            )
        prior = repo.list(
            "extractions", workspace_id, diagnostic_id, document_id=document_id, limit=1000
        )
        if any(r["status"] in {"running", "completed"} for r in prior):
            raise DomainError(
                "An extraction already exists; inspect its status and reviewer queue", 409
            )
        job = repo.insert(
            "extractions",
            workspace_id=workspace_id,
            diagnostic_id=diagnostic_id,
            document_id=document_id,
            model=request.app.state.settings.openai_model,
            started_by=user.id,
        )
    # The running record survives request/process failure. No transaction spans an AI call.
    try:
        result = request.app.state.extractor.extract(document)
        with transaction(request, user, workspace_id, analyst=True) as repo:
            repo.lock_diagnostic(workspace_id, diagnostic_id)
            current = repo.get("extractions", workspace_id, job["id"])
            if current["status"] != "running":
                raise DomainError("Extraction was abandoned; results were not applied", 409)
            docs = document_map(repo, workspace_id, diagnostic_id)
            for table, key, model in [
                ("rules", "rules", CandidateRule),
                ("invoice_lines", "lines", CandidateLine),
            ]:
                existing = repo.list(table, workspace_id, diagnostic_id, limit=5001)
                cap = (
                    request.app.state.settings.max_diagnostic_lines
                    if table == "invoice_lines"
                    else 5000
                )
                if len(existing) + len(result[key]) > cap:
                    raise DomainError(
                        "Extraction exceeds diagnostic item limit; split the audit", 409
                    )
                for item in result[key]:
                    item = model.model_validate(item).model_dump(mode="json")
                    check_sources(item, docs, table)
                    repo.insert(
                        table,
                        workspace_id=workspace_id,
                        diagnostic_id=diagnostic_id,
                        document_id=document_id,
                        extraction_id=job["id"],
                        **item,
                    )
            return repo.update(
                "extractions",
                workspace_id,
                job["id"],
                status="completed",
                response_ids=result["response_ids"],
                warnings=result["warnings"],
                finished_at=datetime.now(timezone.utc),
            )
    except Exception as exc:
        with transaction(request, user, workspace_id, analyst=True) as repo:
            repo.lock_diagnostic(workspace_id, diagnostic_id)
            current = repo.get("extractions", workspace_id, job["id"])
            if current["status"] == "running":
                repo.update(
                    "extractions",
                    workspace_id,
                    job["id"],
                    status="failed",
                    error_code="extraction_failed",
                    finished_at=datetime.now(timezone.utc),
                )
        if isinstance(exc, DomainError):
            raise
        raise DomainError(
            "Extraction failed; inspect the job and use manual entry or retry", 503
        ) from exc


@router.get(D + "/extractions", tags=["Extraction"])
def extractions(
    workspace_id: UUID,
    diagnostic_id: UUID,
    request: Request,
    user: User,
    offset: Annotated[int, Query(ge=0)] = 0,
):
    with transaction(request, user, workspace_id) as repo:
        repo.get("diagnostics", workspace_id, diagnostic_id)
        return repo.list("extractions", workspace_id, diagnostic_id, offset=offset)


@router.post(D + "/extractions/{extraction_id}/abandon", tags=["Extraction"])
def abandon(
    workspace_id: UUID, diagnostic_id: UUID, extraction_id: UUID, request: Request, user: User
):
    with transaction(request, user, workspace_id, analyst=True) as repo:
        repo.lock_diagnostic(workspace_id, diagnostic_id)
        job = in_diagnostic(repo, "extractions", workspace_id, diagnostic_id, extraction_id)
        if job["status"] != "running" or job["created_at"] > datetime.now(timezone.utc) - timedelta(
            hours=1
        ):
            raise DomainError("Only running extractions older than one hour can be abandoned", 409)
        return repo.update(
            "extractions",
            workspace_id,
            extraction_id,
            status="failed",
            error_code="abandoned",
            finished_at=datetime.now(timezone.utc),
        )


def add_candidate(table, data, workspace_id, diagnostic_id, request, user):
    with transaction(request, user, workspace_id, analyst=True) as repo:
        repo.lock_diagnostic(workspace_id, diagnostic_id)
        item = data.model_dump(mode="json")
        docs = document_map(repo, workspace_id, diagnostic_id)
        check_sources(item, docs, table)
        cap = request.app.state.settings.max_diagnostic_lines if table == "invoice_lines" else 5000
        if len(repo.list(table, workspace_id, diagnostic_id, limit=cap + 1)) >= cap:
            raise DomainError("Diagnostic item limit reached", 409)
        return repo.insert(
            table,
            workspace_id=workspace_id,
            diagnostic_id=diagnostic_id,
            document_id=item["evidence"][0]["document_id"],
            **item,
        )


@router.post(D + "/rules", tags=["Rule review"], status_code=201)
def add_rule(
    workspace_id: UUID, diagnostic_id: UUID, data: CandidateRule, request: Request, user: User
):
    return add_candidate("rules", data, workspace_id, diagnostic_id, request, user)


@router.post(D + "/invoice-lines", tags=["Invoice review"], status_code=201)
def add_line(
    workspace_id: UUID, diagnostic_id: UUID, data: CandidateLine, request: Request, user: User
):
    return add_candidate("invoice_lines", data, workspace_id, diagnostic_id, request, user)


@router.get(D + "/review-queue", tags=["Rule review"])
def review_queue(
    workspace_id: UUID,
    diagnostic_id: UUID,
    request: Request,
    user: User,
    offset: Annotated[int, Query(ge=0)] = 0,
):
    with transaction(request, user, workspace_id, analyst=True) as repo:
        repo.get("diagnostics", workspace_id, diagnostic_id)
        return {
            t: repo.list(t, workspace_id, diagnostic_id, status="candidate", offset=offset)
            for t in ("rules", "invoice_lines")
        }


@router.get(D + "/rules", tags=["Rule review"])
def list_rules(
    workspace_id: UUID,
    diagnostic_id: UUID,
    request: Request,
    user: User,
    offset: Annotated[int, Query(ge=0)] = 0,
):
    with transaction(request, user, workspace_id) as repo:
        repo.get("diagnostics", workspace_id, diagnostic_id)
        return repo.list("rules", workspace_id, diagnostic_id, offset=offset)


@router.get(D + "/invoice-lines", tags=["Invoice review"])
def list_lines(
    workspace_id: UUID,
    diagnostic_id: UUID,
    request: Request,
    user: User,
    offset: Annotated[int, Query(ge=0)] = 0,
):
    with transaction(request, user, workspace_id) as repo:
        repo.get("diagnostics", workspace_id, diagnostic_id)
        return repo.list("invoice_lines", workspace_id, diagnostic_id, offset=offset)


def review(table, workspace_id, diagnostic_id, entity_id, data, request, user):
    with transaction(request, user, workspace_id, analyst=True) as repo:
        repo.lock_diagnostic(workspace_id, diagnostic_id)
        row = in_diagnostic(repo, table, workspace_id, diagnostic_id, entity_id)
        rules = (
            repo.list("rules", workspace_id, diagnostic_id, limit=5001)
            if table == "invoice_lines"
            else None
        )
        updated = review_candidate(row, data, str(user.id), rules)
        check_sources(updated, document_map(repo, workspace_id, diagnostic_id), table)
        return repo.update(
            table,
            workspace_id,
            entity_id,
            **{
                k: updated[k]
                for k in ("payload", "evidence", "status", "version", "reviewer_id", "review_note")
            },
        )


@router.post(D + "/rules/{rule_id}/review", tags=["Rule review"])
def review_rule(
    workspace_id: UUID,
    diagnostic_id: UUID,
    rule_id: UUID,
    data: RuleDecision,
    request: Request,
    user: User,
):
    return review("rules", workspace_id, diagnostic_id, rule_id, data, request, user)


@router.post(D + "/invoice-lines/{line_id}/review", tags=["Invoice review"])
def review_line(
    workspace_id: UUID,
    diagnostic_id: UUID,
    line_id: UUID,
    data: LineDecision,
    request: Request,
    user: User,
):
    return review("invoice_lines", workspace_id, diagnostic_id, line_id, data, request, user)


@router.post(D + "/run", tags=["Diagnostics"])
def run(workspace_id: UUID, diagnostic_id: UUID, request: Request, user: User):
    with transaction(request, user, workspace_id, analyst=True) as repo:
        diagnostic = repo.lock_diagnostic(workspace_id, diagnostic_id, draft=False)
        if diagnostic["state"] == "Completed":
            return diagnostic  # Idempotent retry returns the committed snapshot.
        if repo.list("extractions", workspace_id, diagnostic_id, status="running", limit=1):
            raise DomainError("Wait for running extractions before completing the diagnostic", 409)
        lines = repo.list("invoice_lines", workspace_id, diagnostic_id, limit=5001)
        rules = repo.list("rules", workspace_id, diagnostic_id, limit=5001)
        results = calculate_diagnostic(lines, rules)
        docs = document_map(repo, workspace_id, diagnostic_id)
        for row in rules:
            if row["status"] == "approved":
                check_sources(row, docs, "rules")
        for row in lines:
            if row["status"] == "approved":
                check_sources(row, docs, "invoice_lines")
        for result in results:
            if result["classification"] != "Matched":
                repo.insert(
                    "findings",
                    workspace_id=workspace_id,
                    diagnostic_id=diagnostic_id,
                    invoice_line_id=result["invoice_line_id"],
                    payload=result,
                )
        return repo.update(
            "diagnostics",
            workspace_id,
            diagnostic_id,
            state="Completed",
            results=results,
            completed_at=datetime.now(timezone.utc),
        )


@router.get(D + "/findings", tags=["Findings"])
def findings(
    workspace_id: UUID,
    diagnostic_id: UUID,
    request: Request,
    user: User,
    offset: Annotated[int, Query(ge=0)] = 0,
):
    with transaction(request, user, workspace_id) as repo:
        repo.get("diagnostics", workspace_id, diagnostic_id)
        return repo.list("findings", workspace_id, diagnostic_id, offset=offset)


@router.post(D + "/findings/{finding_id}/review", tags=["Findings"])
def finding_review(
    workspace_id: UUID,
    diagnostic_id: UUID,
    finding_id: UUID,
    data: FindingDecision,
    request: Request,
    user: User,
):
    with transaction(request, user, workspace_id, analyst=True) as repo:
        repo.lock_diagnostic(workspace_id, diagnostic_id, draft=False)
        row = in_diagnostic(repo, "findings", workspace_id, diagnostic_id, finding_id)
        updated = decide_finding(row, data, str(user.id))
        return repo.update(
            "findings",
            workspace_id,
            finding_id,
            **{
                k: updated[k]
                for k in ("status", "recovery_status", "version", "reviewer_id", "review_note")
            },
        )


@router.patch(D + "/findings/{finding_id}/recovery", tags=["Recovery"])
def recovery(
    workspace_id: UUID,
    diagnostic_id: UUID,
    finding_id: UUID,
    data: RecoveryDecision,
    request: Request,
    user: User,
):
    with transaction(request, user, workspace_id, analyst=True) as repo:
        repo.lock_diagnostic(workspace_id, diagnostic_id, draft=False)
        row = in_diagnostic(repo, "findings", workspace_id, diagnostic_id, finding_id)
        updated = change_recovery(row, data, str(user.id))
        if updated["recovery_evidence"]:
            docs = document_map(repo, workspace_id, diagnostic_id)
            validate_evidence(updated["recovery_evidence"], docs)
            if any(
                docs[str(e["document_id"])]["kind"] not in {"credit_note", "payment_record"}
                for e in updated["recovery_evidence"]
            ):
                raise DomainError("Recovery evidence must be a credit note or payment record")
        return repo.update(
            "findings",
            workspace_id,
            finding_id,
            **{
                k: updated[k]
                for k in (
                    "recovery_status",
                    "version",
                    "reviewer_id",
                    "review_note",
                    "recovered_amount",
                    "recovery_evidence",
                )
            },
        )


@router.get(D + "/evidence-pack.{format}", tags=["Exports"])
def evidence_pack(
    workspace_id: UUID,
    diagnostic_id: UUID,
    format: Literal["pdf", "xlsx"],
    request: Request,
    user: User,
):
    with transaction(request, user, workspace_id) as repo:
        diagnostic = repo.get("diagnostics", workspace_id, diagnostic_id)
        if diagnostic["state"] != "Completed":
            raise DomainError("Complete the diagnostic before exporting its evidence pack", 409)
        items = repo.list("findings", workspace_id, diagnostic_id, limit=5001)
        docs = document_map(repo, workspace_id, diagnostic_id)
        content = (
            pdf_pack(diagnostic, items, docs)
            if format == "pdf"
            else xlsx_pack(diagnostic, items, docs)
        )
        repo.log_export(workspace_id, diagnostic_id, format)
    mime = (
        "application/pdf"
        if format == "pdf"
        else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    return Response(
        content,
        media_type=mime,
        headers={
            "Content-Disposition": f'attachment; filename="contract-proof-{diagnostic_id}.{format}"'
        },
    )


@router.get(W + "/audit-log", tags=["Audit log"])
def audit_log(
    workspace_id: UUID, request: Request, user: User, offset: Annotated[int, Query(ge=0)] = 0
):
    with transaction(request, user, workspace_id) as repo:
        return repo.list("audit_logs", workspace_id, offset=offset)
