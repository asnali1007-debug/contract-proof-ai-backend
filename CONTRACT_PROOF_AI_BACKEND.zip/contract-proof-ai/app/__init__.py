"""Contract Proof AI - first audit workflow."""
