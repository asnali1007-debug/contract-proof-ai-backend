from datetime import date
from decimal import Decimal
from typing import Annotated, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, model_validator

Money = Annotated[Decimal, Field(ge=0, le=Decimal("999999999"), decimal_places=2)]
Quantity = Annotated[Decimal, Field(ge=0, le=100000, decimal_places=4)]
Currency = Literal["GBP", "EUR", "USD"]
Band = Literal["regular", "overtime", "weekend", "bank_holiday"]
DocumentKind = Literal[
    "contract", "rate_card", "invoice", "payment_record", "credit_note", "timesheet"
]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, allow_inf_nan=False)


class Evidence(StrictModel):
    document_id: UUID
    segment_id: Annotated[str, Field(min_length=1, max_length=100)]
    quote: Annotated[str, Field(min_length=1, max_length=2000)]
    clause: Annotated[str | None, Field(max_length=100)] = None


class RuleTerms(StrictModel):
    supplier: Annotated[str, Field(min_length=1, max_length=200)]
    contract_version: Annotated[str, Field(min_length=1, max_length=100)]
    service_code: Annotated[str, Field(min_length=1, max_length=100)]
    currency: Currency
    effective_from: date
    effective_to: date | None = None
    kind: Literal[
        "contract_version", "hourly_rate", "premium", "management_fee", "variation", "credit"
    ]
    basis: Literal["metadata", "rate", "multiplier", "fixed", "percentage", "rate_delta", "credit"]
    value: Annotated[Decimal | None, Field(ge=-1000000, le=1000000, decimal_places=6)] = None
    band: Literal["all", "regular", "overtime", "weekend", "bank_holiday"] = "all"
    reference: Annotated[str | None, Field(max_length=200)] = None

    @model_validator(mode="after")
    def compatible_terms(self):
        allowed = {
            "contract_version": {"metadata"},
            "hourly_rate": {"rate"},
            "premium": {"multiplier"},
            "management_fee": {"fixed", "percentage"},
            "variation": {"rate_delta", "fixed"},
            "credit": {"credit"},
        }
        if self.basis not in allowed[self.kind]:
            raise ValueError("Rule kind and calculation basis do not agree")
        if self.effective_to and self.effective_to < self.effective_from:
            raise ValueError("Effective end date precedes start date")
        if self.basis == "metadata":
            if self.value is not None:
                raise ValueError("Contract metadata cannot carry a calculation value")
        elif self.value is None:
            raise ValueError("A numeric rule requires an explicit value")
        elif self.basis != "rate_delta" and self.value < 0:
            raise ValueError("Negative values are allowed only for hourly rate variations")
        if self.kind == "premium" and (self.band == "all" or self.value < 1):
            raise ValueError("A premium needs an explicit band and a multiplier of at least one")
        if self.basis == "percentage" and self.value > 100:
            raise ValueError("Percentage must be between 0 and 100")
        if self.kind in {"credit", "variation"} and not self.reference:
            raise ValueError("Credit notes and variations require a unique source reference")
        return self


class InvoiceInput(StrictModel):
    supplier: Annotated[str, Field(min_length=1, max_length=200)]
    contract_version: Annotated[str, Field(min_length=1, max_length=100)]
    service_code: Annotated[str, Field(min_length=1, max_length=100)]
    invoice_number: Annotated[str, Field(min_length=1, max_length=100)]
    line_number: Annotated[str, Field(min_length=1, max_length=50)]
    service_date: date
    currency: Currency
    hours: Quantity
    charged_amount: Money
    band: Band
    contract_rule_id: UUID | None = None
    rate_rule_id: UUID | None = None
    premium_rule_id: UUID | None = None
    adjustment_rule_ids: Annotated[list[UUID], Field(max_length=30)] = []
    hours_evidence: Annotated[list[Evidence], Field(max_length=10)] = []

    @model_validator(mode="after")
    def unique_rules(self):
        ids = [x for x in [self.contract_rule_id, self.rate_rule_id, self.premium_rule_id] if x]
        ids += self.adjustment_rule_ids
        if len(ids) != len(set(ids)):
            raise ValueError("The same rule cannot be applied twice to a line")
        return self


class CandidateRule(StrictModel):
    payload: RuleTerms
    evidence: Annotated[list[Evidence], Field(min_length=1, max_length=10)]
    confidence: Annotated[Decimal, Field(ge=0, le=1)] = Decimal("0")


class CandidateLine(StrictModel):
    payload: InvoiceInput
    evidence: Annotated[list[Evidence], Field(min_length=1, max_length=10)]
    confidence: Annotated[Decimal, Field(ge=0, le=1)] = Decimal("0")


class RuleDecision(StrictModel):
    decision: Literal["approve", "edit", "reject"]
    expected_version: Annotated[int, Field(ge=1)]
    note: Annotated[str, Field(min_length=3, max_length=2000)]
    payload: RuleTerms | None = None
    evidence: Annotated[list[Evidence] | None, Field(min_length=1, max_length=10)] = None


class LineDecision(StrictModel):
    decision: Literal["approve", "edit", "reject"]
    expected_version: Annotated[int, Field(ge=1)]
    note: Annotated[str, Field(min_length=3, max_length=2000)]
    payload: InvoiceInput | None = None
    evidence: Annotated[list[Evidence] | None, Field(min_length=1, max_length=10)] = None


class FindingDecision(StrictModel):
    decision: Literal["validate", "reject"]
    expected_version: Annotated[int, Field(ge=1)]
    note: Annotated[str, Field(min_length=3, max_length=2000)]


RecoveryStatus = Literal[
    "Identified", "Under Review", "Supplier Query", "Credit Note Pending", "Recovered", "Rejected"
]


class RecoveryDecision(StrictModel):
    status: RecoveryStatus
    expected_version: Annotated[int, Field(ge=1)]
    note: Annotated[str, Field(min_length=3, max_length=2000)]
    recovered_amount: Money | None = None
    evidence: Annotated[list[Evidence], Field(max_length=10)] = []


class DiagnosticCreate(StrictModel):
    name: Annotated[str, Field(min_length=1, max_length=200)]


class Login(StrictModel):
    email: Annotated[
        str, Field(min_length=3, max_length=320, pattern=r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
    ]
    password: Annotated[str, Field(min_length=1, max_length=1024)]


class Refresh(StrictModel):
    refresh_token: Annotated[str, Field(min_length=1, max_length=8192)]
