import time
from collections import defaultdict, deque
from threading import Lock

from starlette.responses import JSONResponse

from app.errors import DomainError


class RateLimiter:
    """Per-process abuse control. Put a shared limiter at the ingress when scaling."""

    def __init__(self):
        self.entries = defaultdict(deque)
        self.lock = Lock()

    def check(self, key, limit, period=60):
        now = time.monotonic()
        with self.lock:
            if len(self.entries) > 10000:
                self.entries = defaultdict(
                    deque, {k: v for k, v in self.entries.items() if v and v[-1] > now - period}
                )
            queue = self.entries[key]
            while queue and queue[0] <= now - period:
                queue.popleft()
            if len(queue) >= limit:
                raise DomainError("Rate limit reached; retry later", 429)
            queue.append(now)


class BodyLimitMiddleware:
    def __init__(self, app, max_upload_bytes):
        self.app, self.max_bytes = app, max_upload_bytes

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        limit = self.max_bytes + 65536 if scope["path"].endswith("/documents") else 1024 * 1024
        chunks, size = [], 0
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            size += len(message.get("body", b""))
            if size > limit:
                return await JSONResponse(
                    {"detail": "Request body exceeds limit"}, status_code=413
                )(scope, receive, send)
            chunks.append(message.get("body", b""))
            if not message.get("more_body", False):
                break
        body = b"".join(chunks)
        delivered = False

        async def replay():
            nonlocal delivered
            if delivered:
                return await receive()
            delivered = True
            return {"type": "http.request", "body": body, "more_body": False}

        async def secure_send(message):
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                headers.extend(
                    [
                        (b"x-content-type-options", b"nosniff"),
                        (b"cache-control", b"no-store"),
                        (b"referrer-policy", b"no-referrer"),
                    ]
                )
                message["headers"] = headers
            await send(message)

        await self.app(scope, replay, secure_send)
