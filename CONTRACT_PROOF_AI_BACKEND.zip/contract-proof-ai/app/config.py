from functools import lru_cache
from typing import Literal
from urllib.parse import urlparse

from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    environment: Literal["development", "production"] = "development"
    supabase_url: str
    supabase_anon_key: SecretStr
    supabase_service_role_key: SecretStr
    database_url: SecretStr
    openai_api_key: SecretStr
    openai_model: str = "gpt-6-astra"
    storage_bucket: str = "audit-files"
    cors_origins: list[str] = ["http://localhost:3000"]
    trusted_hosts: list[str] = ["localhost", "127.0.0.1"]
    max_upload_bytes: int = Field(default=20 * 1024 * 1024, ge=1024, le=20 * 1024 * 1024)
    max_text_chars: int = Field(default=400000, ge=1000, le=400000)
    extraction_chunk_chars: int = Field(default=24000, ge=4000, le=40000)
    max_diagnostic_lines: int = Field(default=1000, ge=1, le=5000)
    db_pool_size: int = Field(default=8, ge=1, le=50)

    @model_validator(mode="after")
    def secure_configuration(self):
        url = urlparse(self.supabase_url)
        if url.scheme != "https" and url.hostname not in {"localhost", "127.0.0.1"}:
            raise ValueError("Supabase requires HTTPS except for local development")
        if "*" in self.cors_origins or "*" in self.trusted_hosts:
            raise ValueError("Explicit CORS origins and trusted hosts are required")
        if self.environment == "production":
            if any(not x.startswith("https://") for x in self.cors_origins):
                raise ValueError("Production CORS origins must use HTTPS")
            if "sslmode=require" not in self.database_url.get_secret_value():
                raise ValueError("Production database connection requires sslmode=require")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
