import json
from contextlib import contextmanager
from uuid import uuid4

import pytest

from app.db import Database, Repository
from app.errors import DomainError


class Connection:
    def __init__(self):
        self.statements = []
        self.row = None

    def execute(self, query, params=None):
        self.statements.append((query if isinstance(query, str) else query.as_string(), params))
        return self

    def fetchall(self):
        return []

    def fetchone(self):
        return self.row

    @contextmanager
    def transaction(self):
        yield self


def test_empty_filters_produce_valid_list_query():
    c = Connection()
    Repository(c).list("workspaces")
    query, params = c.statements[0]
    assert 'where true order by "id"' in query and params == [200, 0]


def test_workspace_and_diagnostic_are_parameterised():
    c = Connection()
    w, d = uuid4(), uuid4()
    Repository(c).list("rules", w, d, status="candidate")
    query, params = c.statements[0]
    assert '"workspace_id"=%s' in query and '"diagnostic_id"=%s' in query
    assert str(w) not in query and params == ["candidate", w, d, 200, 0]


def test_only_allowlisted_table_names():
    with pytest.raises(ValueError):
        Repository.table("documents; DROP TABLE auth.users;")


def test_identity_is_set_transaction_locally_for_every_request():
    c = Connection()

    class Pool:
        @contextmanager
        def connection(self):
            yield c

    database = Database.__new__(Database)
    database.pool = Pool()
    for _ in range(2):
        user = uuid4()
        with database.transaction(user):
            pass
        query, params = c.statements[-3]
        assert "set_config('request.jwt.claims',%s,true)" in query
        assert json.loads(params[0])["sub"] == str(user)


def test_upload_lock_does_not_require_row_update_permission():
    c = Connection()
    c.row = {"state": "Draft"}
    Repository(c).lock_diagnostic(uuid4(), uuid4())
    assert "pg_advisory_xact_lock" in c.statements[0][0]
    assert "for update" not in c.statements[1][0].lower()
    c.row = {"state": "Completed"}
    with pytest.raises(DomainError):
        Repository(c).lock_diagnostic(uuid4(), uuid4())
