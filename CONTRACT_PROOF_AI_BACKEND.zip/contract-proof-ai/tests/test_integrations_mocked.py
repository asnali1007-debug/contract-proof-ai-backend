import json
from types import SimpleNamespace
from uuid import uuid4

import httpx
import httpx2
import pytest
from openai import OpenAI

from app.auth import SupabaseAuth
from app.config import Settings
from app.errors import DomainError
from app.extraction import ExtractionOutput, Extractor, RawCandidate
from app.storage import Storage
from tests.fixtures import scenario


def settings():
    return Settings(
        _env_file=None,
        supabase_url="https://project.supabase.co",
        supabase_anon_key="anon",
        supabase_service_role_key="service",
        database_url="postgresql://unused",
        openai_api_key="unused",
    )


def test_auth_verifies_with_supabase_not_unsigned_jwt():
    identifier = uuid4()
    seen = []

    def handle(request):
        seen.append(request)
        return httpx.Response(
            200,
            json={
                "id": str(identifier),
                "email": "a@example.test",
                "user_metadata": {"role": "admin"},
            },
        )

    with httpx.Client(transport=httpx.MockTransport(handle)) as client:
        result = SupabaseAuth(settings(), client).verify("access-token")
    assert result.id == identifier and not hasattr(result, "role")
    assert seen[0].url.path == "/auth/v1/user"
    assert seen[0].headers["authorization"] == "Bearer access-token"
    assert seen[0].headers["apikey"] == "anon"


def test_storage_reader_uses_user_token_writer_only_service_key():
    seen = []

    def handle(request):
        seen.append(request)
        return httpx.Response(200, content=b"file")

    with httpx.Client(transport=httpx.MockTransport(handle)) as client:
        storage = Storage(settings(), client)
        storage.upload("w/d/id.pdf", b"file", "application/pdf")
        assert storage.download("w/d/id.pdf", "user-token") == b"file"
    assert seen[0].headers["authorization"] == "Bearer service"
    assert seen[1].headers["authorization"] == "Bearer user-token"
    assert seen[1].headers["apikey"] == "anon"


def test_extraction_uses_structured_output_no_tools_and_validated_quotes():
    s = scenario()
    doc = s["docs"]["contract"]
    captured = []
    raw = {name: None for name in RawCandidate.model_fields}
    raw.update(
        category="rule",
        kind="hourly_rate",
        basis="rate",
        value="20",
        supplier="Security Ltd",
        contract_version="v1",
        service_code="site A",
        currency="GBP",
        effective_from="2026-01-01",
        band="all",
        segment_id=doc["segments"][0]["id"],
        quote="Guard site A GBP 20 per hour.",
        confidence=0.8,
    )

    def parse(**kwargs):
        captured.append(kwargs)
        output = ExtractionOutput(candidates=[RawCandidate(**raw)], warnings=[])
        return SimpleNamespace(id="resp_test", status="completed", output_parsed=output)

    extractor = Extractor.__new__(Extractor)
    extractor.model = "configured-model"
    extractor.chunk_chars = 24000
    extractor.client = SimpleNamespace(responses=SimpleNamespace(parse=parse))
    result = extractor.extract(doc)
    assert len(result["rules"]) == 1 and "status" not in result["rules"][0]
    assert captured[0]["store"] is False and "tools" not in captured[0]
    assert captured[0]["text_format"] is ExtractionOutput
    assert json.loads(captured[0]["input"][1]["content"])["document_kind"] == "contract"
    raw["quote"] = "invented clause"
    result = extractor.extract(doc)
    assert not result["rules"] and result["warnings"]


def test_auth_provider_failure_is_sanitised():
    with httpx.Client(
        transport=httpx.MockTransport(
            lambda r: httpx.Response(500, text="secret internal exception")
        )
    ) as client:
        with pytest.raises(DomainError) as e:
            SupabaseAuth(settings(), client).verify("token")
    assert e.value.status == 503 and "secret" not in e.value.message


def test_real_openai_sdk_serialises_and_parses_the_structured_contract():
    captured = []

    def handle(request):
        captured.append(json.loads(request.content))
        return httpx2.Response(
            200,
            json={
                "id": "resp_sdk_test",
                "object": "response",
                "created_at": 1,
                "status": "completed",
                "model": "gpt-6-astra",
                "output": [
                    {
                        "id": "msg_test",
                        "type": "message",
                        "role": "assistant",
                        "status": "completed",
                        "content": [
                            {
                                "type": "output_text",
                                "text": '{"candidates":[],"warnings":["Manual review required"]}',
                                "annotations": [],
                            }
                        ],
                    }
                ],
                "parallel_tool_calls": False,
                "tools": [],
                "tool_choice": "auto",
            },
        )

    extractor = Extractor.__new__(Extractor)
    extractor.model = "gpt-6-astra"
    extractor.chunk_chars = 24000
    extractor.client = OpenAI(
        api_key="dummy-test-key", http_client=httpx2.Client(transport=httpx2.MockTransport(handle))
    )
    try:
        output = extractor.extract(scenario()["docs"]["contract"])
    finally:
        extractor.close()
    assert output["response_ids"] == ["resp_sdk_test"]
    body = captured[0]
    assert body["store"] is False and "tools" not in body
    assert body["text"]["format"]["type"] == "json_schema"
    assert body["text"]["format"]["strict"] is True
