"""In-memory adapter for HTTP tests only; real PostgreSQL RLS tests are separate."""

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from uuid import UUID, uuid4

from app.auth import Principal
from app.errors import DomainError


class MemoryDB:
    def __init__(self, s):
        self.tables = {
            t: []
            for t in (
                "workspaces",
                "memberships",
                "diagnostics",
                "documents",
                "extractions",
                "rules",
                "invoice_lines",
                "findings",
                "audit_logs",
            )
        }
        self.client = uuid4()
        self.stranger = uuid4()
        self.analyst = s["reviewer_id"]
        self.workspace = s["workspace_id"]
        self.tables["workspaces"] = [{"id": self.workspace, "name": "Client A"}]
        self.tables["memberships"] = [
            {"workspace_id": self.workspace, "user_id": self.client, "role": "client"},
            {"workspace_id": self.workspace, "user_id": self.analyst, "role": "analyst"},
        ]
        self.tables["diagnostics"] = [
            {
                "id": s["diagnostic_id"],
                "workspace_id": self.workspace,
                "name": "First audit",
                "state": "Draft",
                "results": [],
            }
        ]
        self.tables["documents"] = list(deepcopy(s["docs"]).values())
        self.tables["rules"] = deepcopy(s["rules"])
        self.tables["invoice_lines"] = [deepcopy(s["line"])]

    def open(self):
        pass

    def close(self):
        pass

    @contextmanager
    def transaction(self, user):
        before = deepcopy(self.tables)
        try:
            yield MemoryRepo(self, UUID(str(user)))
        except Exception:
            self.tables = before
            raise


class MemoryRepo:
    def __init__(self, db, user):
        self.db, self.user = db, user

    def allowed(self, w, analyst=False):
        return any(
            x["workspace_id"] == w
            and x["user_id"] == self.user
            and (not analyst or x["role"] == "analyst")
            for x in self.db.tables["memberships"]
        )

    def require_access(self, w, analyst=False):
        if not self.allowed(w, analyst):
            raise DomainError("Workspace not found or role not permitted", 404)

    def list(self, table, workspace_id=None, diagnostic_id=None, limit=200, offset=0, **filters):
        if workspace_id is not None:
            filters["workspace_id"] = workspace_id
        if diagnostic_id is not None:
            filters["diagnostic_id"] = diagnostic_id
        rows = [
            r
            for r in self.db.tables[table]
            if self.allowed(r["id"] if table == "workspaces" else r["workspace_id"])
            and all(str(r.get(k)) == str(v) for k, v in filters.items())
        ]
        return deepcopy(rows[offset : offset + limit])

    def get(self, table, workspace_id, entity_id, lock=False):
        self.require_access(workspace_id)
        for row in self.db.tables[table]:
            if str(row["id"]) == str(entity_id) and (
                table == "workspaces" or row["workspace_id"] == workspace_id
            ):
                return deepcopy(row)
        raise DomainError("Record not found", 404)

    def lock_diagnostic(self, w, d, draft=True):
        row = self.get("diagnostics", w, d)
        if draft and row["state"] != "Draft":
            raise DomainError("Diagnostic inputs are frozen", 409)
        return row

    def insert(self, table, **fields):
        row = {"id": uuid4(), "created_at": datetime.now(timezone.utc), **fields}
        for key in ("document_id", "invoice_line_id"):
            if key in row:
                row[key] = UUID(str(row[key]))
        if table in {"rules", "invoice_lines", "findings"}:
            row.update(
                status="Potential" if table == "findings" else "candidate",
                version=1,
                reviewer_id=None,
                review_note=None,
            )
        if table == "findings":
            row.update(recovery_status="Identified", recovered_amount=None, recovery_evidence=[])
        if table == "diagnostics":
            row.update(state="Draft", results=[])
        if table == "extractions":
            row.update(status="running", warnings=[], response_ids=[])
        self.db.tables[table].append(row)
        return deepcopy(row)

    def update(self, table, w, identifier, **fields):
        self.require_access(w, True)
        for row in self.db.tables[table]:
            if str(row["id"]) == str(identifier) and row["workspace_id"] == w:
                row.update(fields)
                return deepcopy(row)
        raise DomainError("Record not found", 404)

    def log_export(self, w, d, fmt):
        self.insert(
            "audit_logs", workspace_id=w, action="evidence_pack.export", entity_id=d, format=fmt
        )


class FakeAuth:
    def __init__(self, db):
        self.db = db

    def verify(self, token):
        if token not in {"client", "analyst", "stranger"}:
            raise DomainError("Invalid session", 401)
        return Principal(getattr(self.db, token), f"{token}@example.test", token)

    def request(self, *args, **kwargs):
        return {
            "access_token": "client",
            "refresh_token": "refresh",
            "token_type": "bearer",
            "expires_in": 3600,
        }


class FakeStorage:
    def __init__(self):
        self.objects = {}
        self.uploads = 0

    def upload(self, key, data, mime):
        self.objects[key] = data
        self.uploads += 1

    def download(self, key, token):
        return self.objects[key]

    def delete(self, key):
        self.objects.pop(key, None)


class FakeExtractor:
    def __init__(self):
        self.fail = False

    def extract(self, document):
        if self.fail:
            raise DomainError("AI unavailable", 503)
        return {
            "rules": [],
            "lines": [],
            "warnings": ["Manual review required"],
            "response_ids": ["resp_mock"],
        }

    def close(self):
        pass
