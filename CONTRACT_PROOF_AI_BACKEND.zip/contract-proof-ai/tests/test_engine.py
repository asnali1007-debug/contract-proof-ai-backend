from copy import deepcopy
from decimal import Decimal, localcontext
from uuid import uuid4

import pytest
from pydantic import ValidationError

from app.engine import calculate_diagnostic, calculate_line, money
from app.errors import DomainError
from app.models import InvoiceInput, RuleTerms
from tests.fixtures import scenario


def test_variations_premium_percentage_and_credit_exactly():
    s = scenario()
    r = calculate_line(s["line"], s["rules"])
    # 10 * (20+2) * 1.5 + 330*0.10 - 30 = 333; charged 360 => 27.
    assert r["expected_amount"] == "333.00"
    assert r["difference"] == "27.00"
    assert r["calculation"]["percentage_charge"] == "33.0"
    assert len(r["rule_snapshots"]) == 6
    assert r["confidence"]["score"] == "0.90"
    assert r["classification"] == "Potential overcharge"


@pytest.mark.parametrize(
    "value,expected", [("1.005", "1.01"), ("2.675", "2.68"), ("0.004", "0.00"), ("-1.005", "-1.01")]
)
def test_decimal_half_up(value, expected):
    assert str(money(Decimal(value))) == expected


@pytest.mark.parametrize(
    "field,value",
    [
        ("supplier", "Other"),
        ("contract_version", "v2"),
        ("service_code", "site B"),
        ("currency", "USD"),
        ("service_date", "2025-12-31"),
        ("band", "overtime"),
    ],
)
def test_mismatched_rule_scope_is_blocked(field, value):
    s = scenario()
    s["line"]["payload"][field] = value
    with pytest.raises(DomainError):
        calculate_line(s["line"], s["rules"])


@pytest.mark.parametrize("target", ["line", "rate", "hours", "premium", "version"])
def test_approval_and_evidence_gates(target):
    s = scenario()
    if target == "line":
        s["line"]["status"] = "candidate"
    if target == "rate":
        s["rules"][1]["status"] = "candidate"
    if target == "hours":
        s["line"]["payload"]["hours_evidence"] = []
    if target == "premium":
        s["line"]["payload"]["premium_rule_id"] = None
    if target == "version":
        s["line"]["payload"]["contract_rule_id"] = None
    with pytest.raises(DomainError):
        calculate_line(s["line"], s["rules"])


def test_overlapping_rates_are_not_silently_selected():
    s = scenario()
    duplicate = deepcopy(s["rules"][1])
    duplicate["id"] = uuid4()
    with pytest.raises(DomainError, match="Overlapping"):
        calculate_line(s["line"], s["rules"] + [duplicate])


def test_duplicate_invoice_identity_and_credit_reuse_blocked():
    s = scenario()
    second = deepcopy(s["line"])
    second["id"] = uuid4()
    with pytest.raises(DomainError, match="Duplicate"):
        calculate_diagnostic([s["line"], second], s["rules"])
    second["payload"]["line_number"] = "2"
    with pytest.raises(DomainError, match="used twice"):
        calculate_diagnostic([s["line"], second], s["rules"])


def test_unresolved_candidates_stop_whole_diagnostic():
    s = scenario()
    extra = deepcopy(s["rules"][1])
    extra["status"] = "candidate"
    with pytest.raises(DomainError, match="Resolve all"):
        calculate_diagnostic([s["line"]], s["rules"] + [extra])


def test_undercharges_and_zero_differences_are_preserved():
    s = scenario()
    s["line"]["payload"]["charged_amount"] = "300.00"
    assert calculate_line(s["line"], s["rules"])["difference"] == "-33.00"
    s["line"]["payload"]["charged_amount"] = "333.00"
    assert calculate_line(s["line"], s["rules"])["classification"] == "Matched"


@pytest.mark.parametrize("value", ["NaN", "Infinity", "-1", "1.12345"])
def test_invalid_hours_rejected(value):
    s = scenario()
    s["line"]["payload"]["hours"] = value
    with pytest.raises(ValidationError):
        InvoiceInput.model_validate(s["line"]["payload"])


def test_date_bounds_and_credit_reference():
    s = scenario()
    rule = deepcopy(s["rules"][-1]["payload"])
    rule["reference"] = None
    with pytest.raises(ValidationError):
        RuleTerms.model_validate(rule)
    rule = s["rules"][1]["payload"]
    rule["effective_to"] = "2026-01-09"
    with pytest.raises(DomainError):
        calculate_line(s["line"], s["rules"])


def test_negative_expected_charge_requires_allocation():
    s = scenario()
    s["rules"][-1]["payload"]["value"] = "9999"
    with pytest.raises(DomainError, match="Credits exceed"):
        calculate_line(s["line"], s["rules"])


def test_fixed_charge_applied_without_percentage_compounding():
    s = scenario()
    s["rules"][3]["payload"].update(basis="fixed", value="20")
    assert calculate_line(s["line"], s["rules"])["expected_amount"] == "320.00"


def test_calculation_precision_is_independent_of_the_callers_context():
    s = scenario()
    with localcontext() as context:
        context.prec = 3
        assert calculate_line(s["line"], s["rules"])["expected_amount"] == "333.00"
