import io
from uuid import uuid4

from openpyxl import load_workbook
from pypdf import PdfReader

from app.engine import calculate_line
from app.exports import pdf_pack, xlsx_pack
from tests.fixtures import scenario


def export_data():
    s = scenario()
    result = calculate_line(s["line"], s["rules"])
    diagnostic = {"id": s["diagnostic_id"], "name": "Security contract audit", "results": [result]}
    findings = [
        {
            "id": uuid4(),
            "invoice_line_id": s["line"]["id"],
            "status": "Potential",
            "recovery_status": "Identified",
            "reviewer_id": None,
            "version": 1,
            "review_note": None,
            "recovery_evidence": [],
        }
    ]
    return diagnostic, findings, {str(d["id"]): d for d in s["docs"].values()}


def test_pdf_contains_calculation_status_and_evidence():
    data = pdf_pack(*export_data())
    text = "\n".join(p.extract_text() for p in PdfReader(io.BytesIO(data)).pages)
    for expected in ("333.00", "360.00", "27.00", "Potential", "CN-1", "SHA-256", "CSV, row 2"):
        assert expected in text


def test_excel_values_and_formula_injection_protection():
    diagnostic, findings, docs = export_data()
    diagnostic["results"][0]["supplier"] = '=HYPERLINK("https://bad.example","click")'
    findings[0]["review_note"] = "=1+1"
    wb = load_workbook(io.BytesIO(xlsx_pack(diagnostic, findings, docs)), data_only=False)
    assert wb["Calculations"]["F2"].value == 333
    assert wb["Calculations"]["H2"].value == 27
    assert wb["Calculations"]["C2"].data_type == "s"
    assert all(c.data_type != "f" for sheet in wb for row in sheet for c in row)
    assert wb["Evidence"].max_row >= 8
