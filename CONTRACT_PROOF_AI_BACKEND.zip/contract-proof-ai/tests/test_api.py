from uuid import uuid4

import httpx
import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app
from tests.fakes import FakeAuth, FakeExtractor, FakeStorage, MemoryDB
from tests.fixtures import scenario


@pytest.fixture
def api():
    s = scenario()
    db = MemoryDB(s)
    storage = FakeStorage()
    extractor = FakeExtractor()
    settings = Settings(
        _env_file=None,
        supabase_url="https://test.supabase.co",
        supabase_anon_key="dummy",
        supabase_service_role_key="service-secret-must-never-leak",
        database_url="postgresql://contract_api:test@localhost/test",
        openai_api_key="dummy",
        trusted_hosts=["testserver"],
        max_upload_bytes=4096,
    )
    app = create_app(
        settings,
        database=db,
        auth=FakeAuth(db),
        storage=storage,
        extractor=extractor,
        http_client=httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(500))),
    )
    with TestClient(app) as client:
        yield client, s, db, storage, extractor


def path(s):
    return f"/workspaces/{s['workspace_id']}/diagnostics/{s['diagnostic_id']}"


def headers(role):
    return {"Authorization": f"Bearer {role}"}


def test_authentication_required_and_secret_not_exposed(api):
    client, s, *_ = api
    assert client.get("/workspaces").status_code == 401
    assert client.get("/workspaces", headers=headers("expired")).status_code == 401
    r = client.get("/auth/me", headers=headers("client"))
    assert set(r.json()) == {"id", "email"}
    assert "service-secret" not in r.text
    assert r.headers["cache-control"] == "no-store"


def test_cross_workspace_and_client_review_denied(api):
    client, s, db, *_ = api
    assert client.get(path(s), headers=headers("stranger")).status_code == 404
    assert client.get("/workspaces", headers=headers("stranger")).json() == []
    assert client.post(path(s) + "/run", headers=headers("client")).status_code == 404
    assert client.get(path(s) + "/review-queue", headers=headers("client")).status_code == 404
    wrong = path(s).replace(str(s["workspace_id"]), str(uuid4()))
    assert client.get(wrong, headers=headers("analyst")).status_code == 404


def test_full_audit_validation_recovery_and_exports(api):
    client, s, db, *_ = api
    base = path(s)
    h = headers("analyst")
    r = client.post(base + "/run", headers=h)
    assert r.status_code == 200, r.text
    assert r.json()["results"][0]["difference"] == "27.00"
    assert client.post(base + "/run", headers=h).json() == r.json()
    findings = client.get(base + "/findings", headers=headers("client")).json()
    assert len(findings) == 1 and findings[0]["status"] == "Potential"
    f = base + f"/findings/{findings[0]['id']}"
    assert (
        client.patch(
            f + "/recovery",
            headers=h,
            json={"status": "Under Review", "expected_version": 1, "note": "Review started"},
        ).status_code
        == 409
    )
    assert (
        client.post(
            f + "/review",
            headers=h,
            json={"decision": "validate", "expected_version": 1, "note": "Sources checked"},
        ).status_code
        == 200
    )
    assert (
        client.patch(
            f + "/recovery",
            headers=h,
            json={"status": "Under Review", "expected_version": 2, "note": "Review started"},
        ).status_code
        == 200
    )
    doc = s["docs"]["payment_record"]
    recovery = {
        "status": "Recovered",
        "expected_version": 3,
        "note": "Refund received",
        "recovered_amount": "27.00",
        "evidence": [
            {
                "document_id": str(doc["id"]),
                "segment_id": doc["segments"][0]["id"],
                "quote": doc["segments"][0]["text"],
            }
        ],
    }
    response = client.patch(f + "/recovery", headers=h, json=recovery)
    assert response.status_code == 200, response.text
    for fmt, magic in [("pdf", b"%PDF"), ("xlsx", b"PK")]:
        response = client.get(base + f"/evidence-pack.{fmt}", headers=headers("client"))
        assert response.status_code == 200, response.text
        assert response.content.startswith(magic)
    assert len(db.tables["audit_logs"]) == 2


def test_unauthorised_upload_never_touches_storage(api):
    client, s, db, storage, _ = api
    response = client.post(
        path(s) + "/documents",
        headers=headers("stranger"),
        data={"kind": "contract"},
        files={"file": ("contract.csv", b"a\nb\n", "text/csv")},
    )
    assert response.status_code == 404 and storage.uploads == 0


def test_upload_size_type_and_duplicate_checks(api):
    client, s, db, storage, _ = api
    base = path(s) + "/documents"
    h = headers("client")
    r = client.post(
        base,
        headers=h,
        data={"kind": "contract"},
        files={"file": ("sample.csv", b"rate,hours\n20,10\n", "text/csv")},
    )
    assert r.status_code == 201, r.text
    assert "segments" not in r.json() and "object_key" not in r.json()
    assert (
        client.post(
            base,
            headers=h,
            data={"kind": "contract"},
            files={"file": ("sample.csv", b"rate,hours\n20,10\n", "text/csv")},
        ).status_code
        == 409
    )
    assert (
        client.post(
            base,
            headers=h,
            data={"kind": "contract"},
            files={"file": ("large.csv", b"x" * 4097, "text/csv")},
        ).status_code
        == 413
    )
    assert (
        client.post(
            base,
            headers=h,
            data={"kind": "contract"},
            files={"file": ("fake.pdf", b"x", "application/pdf")},
        ).status_code
        == 415
    )
    assert storage.uploads == 1
    r = client.get(base + f"/{r.json()['id']}/download", headers=h)
    assert r.status_code == 200 and r.content == b"rate,hours\n20,10\n"


def test_extraction_failure_is_durable_and_retryable(api):
    client, s, db, _, extractor = api
    url = path(s) + f"/documents/{s['docs']['contract']['id']}/extract"
    extractor.fail = True
    assert client.post(url, headers=headers("analyst")).status_code == 503
    assert db.tables["extractions"][0]["status"] == "failed"
    extractor.fail = False
    assert client.post(url, headers=headers("analyst")).status_code == 201
    assert client.post(url, headers=headers("analyst")).status_code == 409


def test_completed_audit_rejects_new_calculation_inputs(api):
    client, s, *_ = api
    h = headers("analyst")
    assert client.post(path(s) + "/run", headers=h).status_code == 200
    assert (
        client.post(
            path(s) + f"/rules/{s['rules'][0]['id']}/review",
            headers=h,
            json={"decision": "approve", "expected_version": 2, "note": "Change after freeze"},
        ).status_code
        == 409
    )


def test_validation_does_not_echo_secrets(api):
    client, *_ = api
    r = client.post(
        "/auth/login", json={"email": "invalid", "password": "secret-value", "unknown": "private"}
    )
    assert r.status_code == 422 and "secret-value" not in r.text and '"private"' not in r.text


def test_untrusted_host_and_origin(api):
    client, *_ = api
    assert client.get("/health", headers={"host": "evil.test"}).status_code == 400
    response = client.options(
        "/workspaces",
        headers={"Origin": "https://evil.test", "Access-Control-Request-Method": "GET"},
    )
    assert "access-control-allow-origin" not in response.headers
