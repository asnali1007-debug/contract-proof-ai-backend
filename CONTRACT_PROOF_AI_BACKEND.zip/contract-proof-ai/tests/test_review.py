from uuid import uuid4

import pytest

from app.engine import calculate_line
from app.errors import DomainError
from app.models import FindingDecision, RecoveryDecision, RuleDecision
from app.review import change_recovery, decide_finding, review_candidate
from tests.fixtures import scenario


def test_edit_does_not_approve_and_stale_decisions_fail():
    s = scenario()
    row = s["rules"][1]
    row.update(status="candidate", version=1, reviewer_id=None)
    terms = {**row["payload"], "value": "21"}
    edited = review_candidate(
        row,
        RuleDecision(decision="edit", expected_version=1, note="Corrected rate", payload=terms),
        str(s["reviewer_id"]),
    )
    assert edited["status"] == "candidate" and edited["version"] == 2
    decision = RuleDecision(decision="approve", expected_version=1, note="Verified")
    with pytest.raises(DomainError):
        review_candidate(edited, decision, str(s["reviewer_id"]))
    decision.expected_version = 2
    approved = review_candidate(edited, decision, str(s["reviewer_id"]))
    with pytest.raises(DomainError):
        review_candidate(approved, decision, str(s["reviewer_id"]))


def finding():
    s = scenario()
    return {
        "id": uuid4(),
        "payload": calculate_line(s["line"], s["rules"]),
        "status": "Potential",
        "recovery_status": "Identified",
        "version": 1,
        "reviewer_id": None,
    }, s


def test_potential_finding_cannot_progress_recovery():
    row, s = finding()
    with pytest.raises(DomainError, match="human-validated"):
        change_recovery(
            row,
            RecoveryDecision(status="Under Review", expected_version=1, note="Review now"),
            str(s["reviewer_id"]),
        )


def test_validation_and_evidenced_recovery():
    row, s = finding()
    actor = str(s["reviewer_id"])
    row = decide_finding(
        row, FindingDecision(decision="validate", expected_version=1, note="Source verified"), actor
    )
    row = change_recovery(
        row,
        RecoveryDecision(status="Under Review", expected_version=2, note="Review opened"),
        actor,
    )
    doc = s["docs"]["payment_record"]
    ev = [
        {
            "document_id": str(doc["id"]),
            "segment_id": doc["segments"][0]["id"],
            "quote": doc["segments"][0]["text"],
        }
    ]
    row = change_recovery(
        row,
        RecoveryDecision(
            status="Recovered",
            expected_version=3,
            note="Refund received",
            recovered_amount="27.00",
            evidence=ev,
        ),
        actor,
    )
    assert row["recovery_status"] == "Recovered" and str(row["recovered_amount"]) == "27.00"
    with pytest.raises(DomainError):
        change_recovery(
            row,
            RecoveryDecision(status="Under Review", expected_version=4, note="Reopen now"),
            actor,
        )


@pytest.mark.parametrize("amount", [None, "0", "28"])
def test_recovery_without_valid_amount_and_evidence_fails(amount):
    row, s = finding()
    row.update(status="Validated", recovery_status="Under Review")
    with pytest.raises(DomainError):
        change_recovery(
            row,
            RecoveryDecision(
                status="Recovered",
                expected_version=1,
                note="Refund received",
                recovered_amount=amount,
            ),
            str(s["reviewer_id"]),
        )


def test_rejected_finding_stays_rejected():
    row, s = finding()
    actor = str(s["reviewer_id"])
    row = decide_finding(
        row, FindingDecision(decision="reject", expected_version=1, note="No discrepancy"), actor
    )
    assert row["recovery_status"] == "Rejected"
    with pytest.raises(DomainError):
        decide_finding(
            row, FindingDecision(decision="validate", expected_version=2, note="Reconsider"), actor
        )
