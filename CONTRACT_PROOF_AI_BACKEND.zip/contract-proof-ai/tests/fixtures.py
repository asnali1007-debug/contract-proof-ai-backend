from datetime import datetime, timezone
from uuid import uuid4


def scenario():
    workspace, diagnostic, reviewer = uuid4(), uuid4(), uuid4()
    docs = {}
    for kind, text in [
        (
            "contract",
            "Security Ltd contract v1 valid from 2026-01-01. Guard site A GBP 20 per hour. Weekend 1.5 times. Management fee 10 percent of labour. Variation VAR-1 adds GBP 2 per hour.",
        ),
        (
            "invoice",
            "Invoice INV-1 line 1 Security Ltd contract v1 site A service 2026-01-10 weekend 10 hours net charge GBP 360.",
        ),
        ("timesheet", "Approved hours for INV-1 line 1 on 2026-01-10: 10 hours."),
        ("credit_note", "CN-1 Security Ltd contract v1 site A GBP 30 credit effective 2026-01-01."),
        ("payment_record", "REFUND-1 received GBP 27 from Security Ltd for INV-1 line 1."),
    ]:
        identifier = uuid4()
        docs[kind] = {
            "id": identifier,
            "workspace_id": workspace,
            "diagnostic_id": diagnostic,
            "kind": kind,
            "filename": f"{kind}.csv",
            "sha256": "a" * 64,
            "segments": [{"id": "csv:row:2:1", "row": 2, "text": text}],
            "created_at": datetime.now(timezone.utc),
        }

    def evidence(kind):
        d = docs[kind]
        return [
            {
                "document_id": str(d["id"]),
                "segment_id": "csv:row:2:1",
                "quote": d["segments"][0]["text"],
                "clause": "1" if kind == "contract" else None,
            }
        ]

    common = {
        "supplier": "Security Ltd",
        "contract_version": "v1",
        "service_code": "site A",
        "currency": "GBP",
        "effective_from": "2026-01-01",
        "effective_to": None,
        "band": "all",
        "reference": None,
    }
    rules = []

    def add(kind, basis, value, **kw):
        source = "credit_note" if kind == "credit" else "contract"
        rules.append(
            {
                "id": uuid4(),
                "workspace_id": workspace,
                "diagnostic_id": diagnostic,
                "document_id": docs[source]["id"],
                "extraction_id": None,
                "payload": {**common, "kind": kind, "basis": basis, "value": value, **kw},
                "evidence": evidence(source),
                "confidence": "0.90",
                "status": "approved",
                "version": 2,
                "reviewer_id": reviewer,
                "review_note": "Checked against source",
                "created_at": datetime.now(timezone.utc),
            }
        )

    add("contract_version", "metadata", None)
    add("hourly_rate", "rate", "20")
    add("premium", "multiplier", "1.5", band="weekend")
    add("management_fee", "percentage", "10")
    add("variation", "rate_delta", "2", reference="VAR-1")
    add("credit", "credit", "30", reference="CN-1")
    line = {
        "id": uuid4(),
        "workspace_id": workspace,
        "diagnostic_id": diagnostic,
        "document_id": docs["invoice"]["id"],
        "extraction_id": None,
        "payload": {
            "supplier": "Security Ltd",
            "contract_version": "v1",
            "service_code": "site A",
            "currency": "GBP",
            "invoice_number": "INV-1",
            "line_number": "1",
            "service_date": "2026-01-10",
            "hours": "10",
            "charged_amount": "360.00",
            "band": "weekend",
            "contract_rule_id": str(rules[0]["id"]),
            "rate_rule_id": str(rules[1]["id"]),
            "premium_rule_id": str(rules[2]["id"]),
            "adjustment_rule_ids": [str(x["id"]) for x in rules[3:]],
            "hours_evidence": evidence("timesheet"),
        },
        "evidence": evidence("invoice"),
        "confidence": "0.95",
        "status": "approved",
        "version": 2,
        "reviewer_id": reviewer,
        "review_note": "Hours and mappings verified",
        "created_at": datetime.now(timezone.utc),
    }
    return {
        "workspace_id": workspace,
        "diagnostic_id": diagnostic,
        "reviewer_id": reviewer,
        "docs": docs,
        "rules": rules,
        "line": line,
    }
