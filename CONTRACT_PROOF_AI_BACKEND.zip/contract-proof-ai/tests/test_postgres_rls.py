"""Execute real RLS and triggers in an EMPTY, disposable PostgreSQL *_test database.

The tiny auth/storage fixture mimics Supabase's SQL interfaces; it does not test
hosted Auth or the Storage HTTP service. CI runs this suite on PostgreSQL 16.
"""

import hashlib
import json
import os
from pathlib import Path
from uuid import uuid4

import psycopg
import pytest
from psycopg import errors
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from tests.fixtures import scenario

pytestmark = pytest.mark.integration


@pytest.fixture(scope="module")
def database():
    dsn = os.getenv("TEST_DATABASE_URL")
    if not dsn:
        pytest.skip(
            "TEST_DATABASE_URL not set; real PostgreSQL RLS tests require a disposable database"
        )
    connection = psycopg.connect(dsn, row_factory=dict_row, autocommit=True)
    name = connection.execute("select current_database() as name").fetchone()["name"]
    if not name.endswith("_test"):
        pytest.fail("Refusing to initialise schemas outside a disposable *_test database")
    if connection.execute("select 1 from pg_namespace where nspname='contract_proof'").fetchone():
        pytest.fail("Use an empty test database; this suite never drops existing schemas")
    connection.execute("""
      do $$ begin
        if not exists(select 1 from pg_roles where rolname='anon') then create role anon nologin; end if;
        if not exists(select 1 from pg_roles where rolname='authenticated') then create role authenticated nologin; end if;
      end $$;
      create schema auth; create table auth.users(id uuid primary key);
      create function auth.uid() returns uuid language sql stable as $$
        select (nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub')::uuid $$;
      create function auth.role() returns text language sql stable as $$
        select nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'role' $$;
      grant usage on schema auth to authenticated,anon;
      create schema storage;
      create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
      create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text,name text);
      alter table storage.objects enable row level security;
      grant usage on schema storage to authenticated,anon;
      grant select,insert,update,delete on storage.objects to authenticated,anon;
    """)
    for migration in sorted((Path(__file__).resolve().parents[1] / "migrations").glob("*.sql")):
        connection.execute(migration.read_text())
    yield connection
    connection.close()


@pytest.fixture
def seeded(database):
    s = scenario()
    client, other, unassigned = uuid4(), uuid4(), uuid4()
    second_workspace, second_diagnostic = uuid4(), uuid4()
    with database.transaction():
        for user in (s["reviewer_id"], client, other, unassigned):
            database.execute("insert into auth.users(id) values (%s)", (user,))
        for w, d, user in [
            (s["workspace_id"], s["diagnostic_id"], client),
            (second_workspace, second_diagnostic, other),
        ]:
            database.execute(
                "insert into contract_proof.workspaces(id,name) values (%s,'Client')", (w,)
            )
            database.execute(
                "insert into contract_proof.memberships values (%s,%s,'client',now())", (w, user)
            )
            database.execute(
                "insert into contract_proof.diagnostics(id,workspace_id,name,created_by) values (%s,%s,'First audit',%s)",
                (d, w, user),
            )
        database.execute(
            "insert into contract_proof.memberships values (%s,%s,'analyst',now())",
            (s["workspace_id"], s["reviewer_id"]),
        )
        for kind, doc in s["docs"].items():
            key = f"{s['workspace_id']}/{s['diagnostic_id']}/{doc['id']}.csv"
            database.execute(
                """insert into contract_proof.documents(id,workspace_id,diagnostic_id,kind,filename,
                              media_type,byte_size,sha256,object_key,segments,uploaded_by)
                              values (%s,%s,%s,%s,%s,'text/csv',100,%s,%s,%s,%s)""",
                (
                    doc["id"],
                    s["workspace_id"],
                    s["diagnostic_id"],
                    kind,
                    doc["filename"],
                    hashlib.sha256(kind.encode()).hexdigest(),
                    key,
                    Jsonb(doc["segments"]),
                    client,
                ),
            )
            database.execute(
                "insert into storage.objects(bucket_id,name) values ('audit-files',%s)", (key,)
            )
        rule = s["rules"][0]
        database.execute(
            """insert into contract_proof.rules(id,workspace_id,diagnostic_id,document_id,payload,evidence,confidence)
                          values (%s,%s,%s,%s,%s,%s,0.9)""",
            (
                rule["id"],
                s["workspace_id"],
                s["diagnostic_id"],
                rule["document_id"],
                Jsonb(rule["payload"]),
                Jsonb(rule["evidence"]),
            ),
        )
        yield {
            **s,
            "client": client,
            "other": other,
            "unassigned": unassigned,
            "other_workspace": second_workspace,
            "other_diagnostic": second_diagnostic,
            "connection": database,
        }
        # Roll back seeds, leaving only empty schemas for the next test.
        raise psycopg.Rollback()


def impersonate(conn, user, role="contract_api"):
    assert role in {"contract_api", "authenticated", "anon"}
    conn.execute(f"set local role {role}")
    conn.execute(
        "select set_config('request.jwt.claims',%s,true)",
        (
            json.dumps(
                {
                    "sub": str(user) if user else None,
                    "role": "authenticated" if user else "anon",
                    "user_metadata": {"role": "analyst"},
                }
            ),
        ),
    )


def test_clients_only_see_own_workspace_and_cannot_assign_themselves(seeded):
    s = seeded
    c = s["connection"]
    impersonate(c, s["client"])
    assert [r["id"] for r in c.execute("select id from contract_proof.workspaces").fetchall()] == [
        s["workspace_id"]
    ]
    assert c.execute("select count(*) as n from contract_proof.documents").fetchone()["n"] == 5
    with pytest.raises(errors.InsufficientPrivilege), c.transaction():
        c.execute("update contract_proof.memberships set role='analyst'")
    assert (
        c.execute("update contract_proof.rules set status='approved' returning id").fetchall() == []
    )


def test_unassigned_analyst_metadata_does_not_grant_access(seeded):
    s = seeded
    c = s["connection"]
    impersonate(c, s["unassigned"])
    assert c.execute("select * from contract_proof.documents").fetchall() == []
    assert c.execute("select * from contract_proof.audit_logs").fetchall() == []


def test_no_claims_means_no_access(seeded):
    c = seeded["connection"]
    impersonate(c, None)
    assert c.execute("select * from contract_proof.workspaces").fetchall() == []


def test_analyst_review_is_audited_and_approved_rule_immutable(seeded):
    s = seeded
    c = s["connection"]
    impersonate(c, s["reviewer_id"])
    c.execute(
        "update contract_proof.rules set status='approved',version=2,reviewer_id=%s,review_note='Checked source' where id=%s",
        (s["reviewer_id"], s["rules"][0]["id"]),
    )
    event = c.execute(
        "select * from contract_proof.audit_logs where action='rules.update'"
    ).fetchone()
    assert event["actor_id"] == s["reviewer_id"] and event["after_value"]["status"] == "approved"
    with pytest.raises(errors.CheckViolation), c.transaction():
        c.execute(
            "update contract_proof.rules set payload='{}',version=3 where id=%s",
            (s["rules"][0]["id"],),
        )
    with pytest.raises(errors.InsufficientPrivilege), c.transaction():
        c.execute("delete from contract_proof.audit_logs")


def test_cross_workspace_foreign_keys_and_no_auto_approval(seeded):
    s = seeded
    c = s["connection"]
    impersonate(c, s["reviewer_id"])
    rule = s["rules"][0]
    with pytest.raises(errors.ForeignKeyViolation), c.transaction():
        c.execute(
            """insert into contract_proof.rules(workspace_id,diagnostic_id,document_id,payload,evidence,confidence)
                     values (%s,%s,%s,%s,%s,0.9)""",
            (
                s["workspace_id"],
                s["other_diagnostic"],
                rule["document_id"],
                Jsonb(rule["payload"]),
                Jsonb(rule["evidence"]),
            ),
        )
    with pytest.raises(errors.CheckViolation), c.transaction():
        c.execute(
            """insert into contract_proof.rules(workspace_id,diagnostic_id,document_id,payload,evidence,confidence,status,reviewer_id,review_note)
                     values (%s,%s,%s,%s,%s,0.9,'approved',%s,'Automatic approval')""",
            (
                s["workspace_id"],
                s["diagnostic_id"],
                rule["document_id"],
                Jsonb(rule["payload"]),
                Jsonb(rule["evidence"]),
                s["reviewer_id"],
            ),
        )


def test_storage_read_is_scoped_and_direct_upload_blocked(seeded):
    s = seeded
    c = s["connection"]
    impersonate(c, s["client"], "authenticated")
    assert c.execute("select count(*) as n from storage.objects").fetchone()["n"] == 5
    with pytest.raises(errors.InsufficientPrivilege), c.transaction():
        c.execute("insert into storage.objects(bucket_id,name) values ('audit-files','rogue.pdf')")
    c.execute("reset role")
    impersonate(c, s["other"], "authenticated")
    assert c.execute("select * from storage.objects").fetchall() == []


def test_client_can_upload_without_updating_diagnostic(seeded):
    s = seeded
    c = s["connection"]
    impersonate(c, s["client"])
    # Same advisory-lock path used by the real repository.
    c.execute(
        "select pg_advisory_xact_lock(hashtextextended(%s,0))",
        (f"{s['workspace_id']}/{s['diagnostic_id']}",),
    )
    assert (
        c.execute("update contract_proof.diagnostics set state='Completed' returning id").fetchall()
        == []
    )
    identifier = uuid4()
    c.execute(
        """insert into contract_proof.documents(id,workspace_id,diagnostic_id,kind,filename,media_type,byte_size,
                 sha256,object_key,segments,uploaded_by) values (%s,%s,%s,'invoice','new.csv','text/csv',10,%s,%s,'[]',%s)""",
        (
            identifier,
            s["workspace_id"],
            s["diagnostic_id"],
            "b" * 64,
            f"{s['workspace_id']}/{s['diagnostic_id']}/{identifier}.csv",
            s["client"],
        ),
    )
    assert (
        c.execute(
            "select count(*) as n from contract_proof.audit_logs where entity_id=%s and action='documents.insert'",
            (identifier,),
        ).fetchone()["n"]
        == 1
    )
