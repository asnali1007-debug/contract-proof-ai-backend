import io
import zipfile
from uuid import uuid4

import pytest
from openpyxl import Workbook
from reportlab.pdfgen.canvas import Canvas

from app.errors import DomainError
from app.parsers import parse_file, parse_isolated, validate_evidence, validate_upload
from tests.fixtures import scenario


@pytest.mark.parametrize(
    "name,mime,data",
    [
        ("bad.exe", "application/octet-stream", b"MZabc"),
        ("../a.pdf", "application/pdf", b"%PDF-1.7"),
        ("bad.pdf", "application/pdf", b"not PDF"),
        ("bad.xlsx", "application/pdf", b"PK\x03\x04"),
        ("bad.csv", "text/csv", b""),
    ],
)
def test_invalid_uploads(name, mime, data):
    with pytest.raises(DomainError):
        validate_upload(name, mime, data, 20)


def test_file_size_limit_and_binary_csv():
    with pytest.raises(DomainError):
        validate_upload("a.csv", "text/csv", b"x" * 21, 20)
    with pytest.raises(DomainError):
        parse_file(b"a,b\n1,\x00", ".csv")


def test_csv_locations_and_no_silent_truncation():
    s = parse_file(b"rate,hours\n20,10\n", ".csv")
    assert s[1]["row"] == 2 and s[1]["text"] == "rate=20 | hours=10"
    with pytest.raises(DomainError):
        parse_file(b"rate,hours\n20,10\n", ".csv", max_chars=5)
    with pytest.raises(DomainError):
        parse_file(b"a,b\n1,2,3", ".csv")


def test_xlsx_locations_and_formula_rejection():
    w = Workbook()
    w.active.title = "Rates"
    w.active.append(["rate", "hours"])
    w.active.append([20, 10])
    out = io.BytesIO()
    w.save(out)
    s = parse_file(out.getvalue(), ".xlsx")
    assert s[1]["sheet"] == "Rates" and s[1]["row"] == 2
    w.active["A2"] = '=HYPERLINK("https://example.com")'
    out = io.BytesIO()
    w.save(out)
    with pytest.raises(DomainError, match="formula"):
        parse_file(out.getvalue(), ".xlsx")


def test_zip_bomb_rejected():
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("xl/workbook.xml", "x" * 2000000)
    with pytest.raises(DomainError, match="compression"):
        parse_file(out.getvalue(), ".xlsx")


def test_pdf_and_process_isolation():
    out = io.BytesIO()
    c = Canvas(out)
    c.drawString(20, 700, "Contract hourly rate GBP 20")
    c.save()
    s = parse_isolated(out.getvalue(), ".pdf", 10000)
    assert s[0]["page"] == 1 and "GBP 20" in s[0]["text"]


def test_fabricated_and_foreign_document_evidence_rejected():
    s = scenario()
    docs = {str(d["id"]): d for d in s["docs"].values()}
    ev = s["line"]["evidence"]
    validate_evidence(ev, docs)
    ev[0]["quote"] = "invented quote"
    with pytest.raises(DomainError):
        validate_evidence(ev, docs)
    ev[0]["document_id"] = str(uuid4())
    with pytest.raises(DomainError):
        validate_evidence(ev, docs)
