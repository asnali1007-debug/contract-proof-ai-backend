"""Assign existing Supabase Auth user IDs. Does not create users or send invitations."""

import argparse
import getpass
import os
from uuid import UUID

import psycopg
from dotenv import load_dotenv
from psycopg import sql
from psycopg.types.json import Jsonb


def main():
    load_dotenv()
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace-name", required=True)
    parser.add_argument("--workspace-id", type=UUID, help="Assign members to an existing workspace")
    parser.add_argument("--client", type=UUID, required=True)
    parser.add_argument("--analyst", type=UUID, required=True)
    parser.add_argument("--set-api-password", action="store_true")
    args = parser.parse_args()
    if args.client == args.analyst:
        parser.error("Client and internal analyst must be different user IDs")
    dsn = os.getenv("ADMIN_DATABASE_URL")
    if not dsn:
        raise SystemExit("Set ADMIN_DATABASE_URL for this one-off command")
    with psycopg.connect(dsn) as connection:
        if args.set_api_password:
            password = getpass.getpass(
                "New contract_api database password (minimum 24 characters): "
            )
            if len(password) < 24:
                raise SystemExit("Password is too short")
            connection.execute(
                sql.SQL("alter role contract_api password {}").format(sql.Literal(password))
            )
        if args.workspace_id:
            found = connection.execute(
                "select id from contract_proof.workspaces where id=%s", (args.workspace_id,)
            ).fetchone()
            if not found:
                raise SystemExit("Workspace not found")
            workspace = args.workspace_id
        else:
            workspace = connection.execute(
                "insert into contract_proof.workspaces(name) values (%s) returning id",
                (args.workspace_name,),
            ).fetchone()[0]
        for user, role in [(args.client, "client"), (args.analyst, "analyst")]:
            # Do not silently change an existing role; use an explicitly reviewed admin change.
            old = connection.execute(
                "select role from contract_proof.memberships where workspace_id=%s and user_id=%s",
                (workspace, user),
            ).fetchone()
            if old and old[0] != role:
                raise SystemExit(
                    "Existing membership has another role; review that assignment separately"
                )
            connection.execute(
                "insert into contract_proof.memberships(workspace_id,user_id,role) values (%s,%s,%s) on conflict do nothing",
                (workspace, user, role),
            )
            connection.execute(
                "insert into contract_proof.audit_logs(workspace_id,action,after_value) values (%s,'membership.provisioned',%s)",
                (
                    workspace,
                    Jsonb(
                        {"user_id": str(user), "role": role, "source": "admin provisioning script"}
                    ),
                ),
            )
    print(f"Workspace ready: {workspace}")


if __name__ == "__main__":
    main()
