"""Apply immutable, checksummed migrations with a separate admin connection."""

import hashlib
import os
from pathlib import Path

import psycopg
from dotenv import load_dotenv


def main():
    load_dotenv()
    dsn = os.getenv("ADMIN_DATABASE_URL")
    if not dsn:
        raise SystemExit(
            "Set ADMIN_DATABASE_URL for this one-off command; do not use the runtime DB login"
        )
    with psycopg.connect(dsn) as connection:
        connection.execute("select pg_advisory_xact_lock(715233923)")
        connection.execute("""create table if not exists public.contract_proof_migrations(
                           name text primary key,sha256 text not null,applied_at timestamptz not null default now())""")
        connection.execute(
            "revoke all on public.contract_proof_migrations from public,anon,authenticated"
        )
        for path in sorted((Path(__file__).resolve().parents[1] / "migrations").glob("*.sql")):
            source = path.read_text()
            digest = hashlib.sha256(source.encode()).hexdigest()
            applied = connection.execute(
                "select sha256 from public.contract_proof_migrations where name=%s", (path.name,)
            ).fetchone()
            if applied:
                if applied[0] != digest:
                    raise SystemExit(f"Migration {path.name} has changed since it was applied")
                continue
            connection.execute(source)
            connection.execute(
                "insert into public.contract_proof_migrations(name,sha256) values (%s,%s)",
                (path.name, digest),
            )
            print(f"Applied {path.name}")
    print("Migrations committed")


if __name__ == "__main__":
    main()
